"""
routers/events.py — POST /events/ingest
"""
import logging
import uuid
from fastapi import APIRouter, Request, HTTPException
from app.models import IngestRequest, IngestResponse, ErrorResponse
from app.services.ingestion import ingest_events

log = logging.getLogger("router.events")
router = APIRouter(tags=["events"])


@router.post(
    "/events/ingest",
    response_model=IngestResponse,
    responses={400: {"model": ErrorResponse}, 503: {"model": ErrorResponse}},
    summary="Ingest a batch of store events (up to 500)",
)
async def ingest(request: Request, payload: IngestRequest):
    trace_id = request.state.trace_id
    log.info(f"[{trace_id}] Ingest request: {len(payload.events)} events")

    try:
        result = await ingest_events(payload.events)
        return result
    except Exception as e:
        log.error(f"[{trace_id}] Ingest failed: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail={
            "error": "Database unavailable",
            "trace_id": trace_id,
        })
