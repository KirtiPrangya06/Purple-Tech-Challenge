"""
routers/health.py — GET /health
"""
from fastapi import APIRouter, Request
from app.models import HealthResponse
from app.services.health import get_health

router = APIRouter(tags=["health"])


@router.get("/health", response_model=HealthResponse, summary="Service health + feed status")
async def health(request: Request):
    return await get_health()
