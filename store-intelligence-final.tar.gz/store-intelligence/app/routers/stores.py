"""
routers/stores.py — Store analytics endpoints

GET /stores/{store_id}/metrics
GET /stores/{store_id}/funnel
GET /stores/{store_id}/heatmap
GET /stores/{store_id}/anomalies
"""
import logging
from fastapi import APIRouter, Request, HTTPException, Query
from app.models import StoreMetrics, StoreFunnel, StoreHeatmap, AnomalyResponse, ErrorResponse
from app.services.metrics import get_store_metrics
from app.services.funnel import get_store_funnel
from app.services.heatmap import get_store_heatmap
from app.services.anomalies import get_store_anomalies

log = logging.getLogger("router.stores")
router = APIRouter(tags=["stores"])


@router.get(
    "/stores/{store_id}/metrics",
    response_model=StoreMetrics,
    responses={503: {"model": ErrorResponse}},
    summary="Real-time store metrics: visitors, conversion, dwell, queue depth",
)
async def metrics(
    store_id: str,
    request: Request,
    window_hours: int = Query(default=24, ge=1, le=168, description="Lookback window in hours"),
):
    trace_id = request.state.trace_id
    try:
        return await get_store_metrics(store_id, window_hours)
    except Exception as e:
        log.error(f"[{trace_id}] metrics failed for {store_id}: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail={
            "error": "Database unavailable",
            "trace_id": trace_id,
        })


@router.get(
    "/stores/{store_id}/funnel",
    response_model=StoreFunnel,
    responses={503: {"model": ErrorResponse}},
    summary="Conversion funnel: Entry → Zone Visit → Billing → Purchase",
)
async def funnel(
    store_id: str,
    request: Request,
    window_hours: int = Query(default=24, ge=1, le=168),
):
    trace_id = request.state.trace_id
    try:
        return await get_store_funnel(store_id, window_hours)
    except Exception as e:
        log.error(f"[{trace_id}] funnel failed for {store_id}: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail={
            "error": "Database unavailable",
            "trace_id": trace_id,
        })


@router.get(
    "/stores/{store_id}/heatmap",
    response_model=StoreHeatmap,
    responses={503: {"model": ErrorResponse}},
    summary="Zone visit frequency and dwell heatmap (normalised 0–100)",
)
async def heatmap(
    store_id: str,
    request: Request,
    window_hours: int = Query(default=24, ge=1, le=168),
):
    trace_id = request.state.trace_id
    try:
        return await get_store_heatmap(store_id, window_hours)
    except Exception as e:
        log.error(f"[{trace_id}] heatmap failed for {store_id}: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail={
            "error": "Database unavailable",
            "trace_id": trace_id,
        })


@router.get(
    "/stores/{store_id}/anomalies",
    response_model=AnomalyResponse,
    responses={503: {"model": ErrorResponse}},
    summary="Active anomalies: queue spikes, conversion drops, dead zones, stale feeds",
)
async def anomalies(
    store_id: str,
    request: Request,
    window_hours: int = Query(default=24, ge=1, le=168),
):
    trace_id = request.state.trace_id
    try:
        return await get_store_anomalies(store_id)
    except Exception as e:
        log.error(f"[{trace_id}] anomalies failed for {store_id}: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail={
            "error": "Database unavailable",
            "trace_id": trace_id,
        })
