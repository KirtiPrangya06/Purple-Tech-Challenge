"""
routers/pos.py — POST /pos/ingest for POS transaction data
             — GET /stores for listing known stores
"""
import logging
from typing import List, Optional
from fastapi import APIRouter, Request, HTTPException
from pydantic import BaseModel
from app.models import ErrorResponse
from app.services.ingestion import ingest_pos_transactions
from app.db.database import get_db

log = logging.getLogger("router.pos")
router = APIRouter(tags=["pos"])


class PosTransaction(BaseModel):
    store_id: str
    transaction_id: str
    timestamp: str
    basket_value_inr: float = 0.0


class PosIngestRequest(BaseModel):
    transactions: List[PosTransaction]


class PosIngestResponse(BaseModel):
    ingested: int
    duplicates: int
    status: str


class StoreInfo(BaseModel):
    store_id: str
    last_event_at: Optional[str]
    total_events: int


@router.post(
    "/pos/ingest",
    response_model=PosIngestResponse,
    responses={503: {"model": ErrorResponse}},
    summary="Ingest POS transaction records for conversion rate calculation",
)
async def ingest_pos(request: Request, payload: PosIngestRequest):
    trace_id = request.state.trace_id
    try:
        txns = [t.model_dump() for t in payload.transactions]
        inserted, dupes = await ingest_pos_transactions(txns)
        return PosIngestResponse(ingested=inserted, duplicates=dupes, status="ok")
    except Exception as e:
        log.error(f"[{trace_id}] POS ingest failed: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail={
            "error": "Database unavailable",
            "trace_id": trace_id,
        })


@router.get(
    "/stores",
    response_model=List[StoreInfo],
    summary="List all stores with known event data",
)
async def list_stores(request: Request):
    trace_id = request.state.trace_id
    try:
        async with get_db() as db:
            rows = await (await db.execute("""
                SELECT store_id,
                       MAX(timestamp) as last_event_at,
                       COUNT(*) as total_events
                FROM events
                GROUP BY store_id
                ORDER BY store_id
            """)).fetchall()
        return [
            StoreInfo(
                store_id=r["store_id"],
                last_event_at=r["last_event_at"],
                total_events=r["total_events"],
            )
            for r in rows
        ]
    except Exception as e:
        log.error(f"[{trace_id}] list_stores failed: {e}", exc_info=True)
        raise HTTPException(status_code=503, detail={
            "error": "Database unavailable",
            "trace_id": trace_id,
        })
