"""
db/database.py — Database layer for Store Intelligence API

Uses SQLite (via aiosqlite for async) with a schema designed for:
  - Fast event ingest with idempotency (dedup by event_id)
  - Efficient real-time metric queries (indexed by store_id + timestamp)
  - Session-level analytics (funnel, re-entry, conversion)

Schema design decisions:
  - Single events table — denormalised for query simplicity
  - Partial indexes on (store_id, timestamp) for time-window scans
  - Separate pos_transactions table for POS correlation
  - sessions view materialised on demand (not stored) — avoids stale cache
"""

import aiosqlite
import logging
import os
from pathlib import Path
from typing import Optional, AsyncGenerator
from contextlib import asynccontextmanager

log = logging.getLogger("db")

DB_PATH = os.getenv("DATABASE_URL", "./data/store_intelligence.db").replace("sqlite:///", "")


CREATE_EVENTS_TABLE = """
CREATE TABLE IF NOT EXISTS events (
    event_id        TEXT PRIMARY KEY,
    store_id        TEXT NOT NULL,
    camera_id       TEXT NOT NULL,
    visitor_id      TEXT NOT NULL,
    event_type      TEXT NOT NULL,
    timestamp       TEXT NOT NULL,
    zone_id         TEXT,
    dwell_ms        INTEGER DEFAULT 0,
    is_staff        INTEGER DEFAULT 0,   -- 0/1 boolean
    confidence      REAL DEFAULT 0.0,
    queue_depth     INTEGER,
    sku_zone        TEXT,
    session_seq     INTEGER,
    ingested_at     TEXT DEFAULT (datetime('now'))
);
"""

CREATE_POS_TABLE = """
CREATE TABLE IF NOT EXISTS pos_transactions (
    transaction_id  TEXT PRIMARY KEY,
    store_id        TEXT NOT NULL,
    timestamp       TEXT NOT NULL,
    basket_value    REAL DEFAULT 0.0,
    ingested_at     TEXT DEFAULT (datetime('now'))
);
"""

CREATE_INDEXES = [
    "CREATE INDEX IF NOT EXISTS idx_events_store_ts ON events(store_id, timestamp);",
    "CREATE INDEX IF NOT EXISTS idx_events_visitor ON events(visitor_id);",
    "CREATE INDEX IF NOT EXISTS idx_events_type ON events(event_type);",
    "CREATE INDEX IF NOT EXISTS idx_events_store_type ON events(store_id, event_type);",
    "CREATE INDEX IF NOT EXISTS idx_pos_store_ts ON pos_transactions(store_id, timestamp);",
]


async def init_db(db_path: str = DB_PATH):
    """Initialise database schema. Safe to call multiple times."""
    Path(db_path).parent.mkdir(parents=True, exist_ok=True)
    async with aiosqlite.connect(db_path) as db:
        await db.execute("PRAGMA journal_mode=WAL;")
        await db.execute("PRAGMA synchronous=NORMAL;")
        await db.execute("PRAGMA cache_size=-64000;")  # 64MB cache
        await db.execute(CREATE_EVENTS_TABLE)
        await db.execute(CREATE_POS_TABLE)
        for idx in CREATE_INDEXES:
            await db.execute(idx)
        await db.commit()
    log.info(f"Database initialised at {db_path}")


@asynccontextmanager
async def get_db() -> AsyncGenerator[aiosqlite.Connection, None]:
    """Async context manager for DB connections."""
    db = await aiosqlite.connect(DB_PATH)
    db.row_factory = aiosqlite.Row
    try:
        await db.execute("PRAGMA journal_mode=WAL;")
        yield db
    finally:
        await db.close()


async def check_db_health() -> bool:
    """Returns True if DB is accessible."""
    try:
        async with get_db() as db:
            await db.execute("SELECT 1")
        return True
    except Exception:
        return False
