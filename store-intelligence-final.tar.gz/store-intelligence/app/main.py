"""
main.py — FastAPI entrypoint for Store Intelligence API

Features:
  - Trace ID injected on every request (X-Trace-ID header or generated)
  - Structured JSON logging: trace_id, store_id, endpoint, latency_ms, status_code
  - Graceful DB degradation: 503 with structured body, no raw stack traces
  - CORS enabled for dashboard integration
  - Lifespan: DB init on startup, cleanup on shutdown
"""

import logging
import time
import uuid
import json
import sys
import os
from contextlib import asynccontextmanager
from datetime import datetime, timezone

import uvicorn
from fastapi import FastAPI, Request, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.db.database import init_db
from app.routers import events, stores, health, pos

# ── Structured logging setup ───────────────────────────────────────────────────

class JSONFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_entry = {
            "time": datetime.now(timezone.utc).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info:
            log_entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(log_entry)


def setup_logging():
    root = logging.getLogger()
    root.setLevel(logging.INFO)
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(JSONFormatter())
    root.handlers = [handler]


setup_logging()
log = logging.getLogger("main")


# ── Application lifespan ───────────────────────────────────────────────────────

@asynccontextmanager
async def lifespan(app: FastAPI):
    log.info("Starting Store Intelligence API...")
    try:
        await init_db()
        log.info("Database initialised")
    except Exception as e:
        log.error(f"Database init failed: {e}")
        # Don't crash — allow health endpoint to report degraded state
    yield
    log.info("Store Intelligence API shutting down")


# ── App factory ────────────────────────────────────────────────────────────────

app = FastAPI(
    title="Store Intelligence API",
    description="Real-time retail analytics from CCTV event streams",
    version="1.0.0",
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Request logging middleware ─────────────────────────────────────────────────

@app.middleware("http")
async def logging_middleware(request: Request, call_next):
    trace_id = request.headers.get("X-Trace-ID") or str(uuid.uuid4())[:8]
    request.state.trace_id = trace_id

    start = time.time()

    # Extract store_id from path if present
    path_parts = request.url.path.split("/")
    store_id = None
    if "stores" in path_parts:
        idx = path_parts.index("stores")
        if idx + 1 < len(path_parts):
            store_id = path_parts[idx + 1]

    try:
        response: Response = await call_next(request)
    except Exception as e:
        latency_ms = round((time.time() - start) * 1000, 1)
        log.error(json.dumps({
            "trace_id": trace_id,
            "store_id": store_id,
            "endpoint": request.url.path,
            "method": request.method,
            "latency_ms": latency_ms,
            "status_code": 500,
            "error": str(e),
        }))
        return JSONResponse(
            status_code=500,
            content={"error": "Internal server error", "trace_id": trace_id},
        )

    latency_ms = round((time.time() - start) * 1000, 1)
    log.info(json.dumps({
        "trace_id": trace_id,
        "store_id": store_id,
        "endpoint": request.url.path,
        "method": request.method,
        "latency_ms": latency_ms,
        "status_code": response.status_code,
    }))

    response.headers["X-Trace-ID"] = trace_id
    return response


# ── Exception handlers ─────────────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    trace_id = getattr(request.state, "trace_id", str(uuid.uuid4())[:8])
    log.error(f"[{trace_id}] Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "trace_id": trace_id},
    )


# ── Routers ────────────────────────────────────────────────────────────────────

app.include_router(events.router)
app.include_router(stores.router)
app.include_router(health.router)
app.include_router(pos.router)


# ── Dev entrypoint ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    port = int(os.getenv("PORT", 8000))
    uvicorn.run("app.main:app", host="0.0.0.0", port=port, reload=False)
