"""
models.py — Pydantic schemas for events, API requests, and responses.
"""

from __future__ import annotations
from datetime import datetime
from typing import Optional, List, Any
from enum import Enum
import uuid

from pydantic import BaseModel, Field, field_validator, model_validator


# ── Event Types ────────────────────────────────────────────────────────────────

class EventType(str, Enum):
    ENTRY = "ENTRY"
    EXIT = "EXIT"
    ZONE_ENTER = "ZONE_ENTER"
    ZONE_EXIT = "ZONE_EXIT"
    ZONE_DWELL = "ZONE_DWELL"
    BILLING_QUEUE_JOIN = "BILLING_QUEUE_JOIN"
    BILLING_QUEUE_ABANDON = "BILLING_QUEUE_ABANDON"
    REENTRY = "REENTRY"


# ── Event Schema ───────────────────────────────────────────────────────────────

class EventMetadata(BaseModel):
    queue_depth: Optional[int] = None
    sku_zone: Optional[str] = None
    session_seq: Optional[int] = None

    model_config = {"extra": "allow"}


class StoreEvent(BaseModel):
    event_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    store_id: str
    camera_id: str
    visitor_id: str
    event_type: EventType
    timestamp: str                      # ISO-8601 UTC string
    zone_id: Optional[str] = None
    dwell_ms: int = 0
    is_staff: bool = False
    confidence: float = Field(ge=0.0, le=1.0)
    metadata: EventMetadata = Field(default_factory=EventMetadata)

    @field_validator("event_id")
    @classmethod
    def validate_uuid(cls, v: str) -> str:
        try:
            uuid.UUID(v)
        except ValueError:
            raise ValueError(f"event_id must be a valid UUID: {v!r}")
        return v

    @field_validator("timestamp")
    @classmethod
    def validate_timestamp(cls, v: str) -> str:
        # Accept ISO-8601 with Z or +00:00
        v_norm = v.replace("Z", "+00:00")
        try:
            datetime.fromisoformat(v_norm)
        except ValueError:
            raise ValueError(f"timestamp must be ISO-8601 UTC: {v!r}")
        return v

    @field_validator("dwell_ms")
    @classmethod
    def validate_dwell(cls, v: int) -> int:
        return max(0, v)

    @property
    def parsed_timestamp(self) -> datetime:
        return datetime.fromisoformat(self.timestamp.replace("Z", "+00:00"))


# ── Ingest Request / Response ──────────────────────────────────────────────────

class IngestRequest(BaseModel):
    events: List[StoreEvent] = Field(..., max_length=500)


class EventError(BaseModel):
    event_id: Optional[str] = None
    index: int
    error: str


class IngestResponse(BaseModel):
    ingested: int
    duplicates: int
    errors: int
    error_details: List[EventError] = []
    status: str  # "ok" | "partial"


# ── Metrics ────────────────────────────────────────────────────────────────────

class ZoneDwellMetric(BaseModel):
    zone_id: str
    avg_dwell_ms: float
    visit_count: int


class StoreMetrics(BaseModel):
    store_id: str
    window_start: str
    window_end: str
    unique_visitors: int
    conversion_rate: float         # 0.0–1.0
    avg_dwell_per_zone: List[ZoneDwellMetric]
    queue_depth: int               # current billing queue depth
    abandonment_rate: float        # 0.0–1.0
    total_transactions: int
    data_confidence: str           # "HIGH" | "LOW" (< 20 sessions)


# ── Funnel ─────────────────────────────────────────────────────────────────────

class FunnelStage(BaseModel):
    stage: str
    count: int
    drop_off_pct: float            # percentage lost at this stage


class StoreFunnel(BaseModel):
    store_id: str
    window_start: str
    window_end: str
    stages: List[FunnelStage]
    session_count: int


# ── Heatmap ────────────────────────────────────────────────────────────────────

class HeatmapZone(BaseModel):
    zone_id: str
    visit_frequency: int
    avg_dwell_ms: float
    normalised_score: float        # 0–100
    sku_zone: Optional[str] = None


class StoreHeatmap(BaseModel):
    store_id: str
    window_start: str
    window_end: str
    zones: List[HeatmapZone]
    data_confidence: str           # "HIGH" | "LOW"


# ── Anomalies ──────────────────────────────────────────────────────────────────

class AnomalySeverity(str, Enum):
    INFO = "INFO"
    WARN = "WARN"
    CRITICAL = "CRITICAL"


class AnomalyType(str, Enum):
    BILLING_QUEUE_SPIKE = "BILLING_QUEUE_SPIKE"
    CONVERSION_DROP = "CONVERSION_DROP"
    DEAD_ZONE = "DEAD_ZONE"
    STALE_FEED = "STALE_FEED"
    EMPTY_STORE = "EMPTY_STORE"


class Anomaly(BaseModel):
    anomaly_id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    anomaly_type: AnomalyType
    severity: AnomalySeverity
    store_id: str
    zone_id: Optional[str] = None
    detected_at: str
    description: str
    suggested_action: str
    metric_value: Optional[float] = None
    threshold_value: Optional[float] = None


class AnomalyResponse(BaseModel):
    store_id: str
    active_anomalies: List[Anomaly]
    checked_at: str


# ── Health ─────────────────────────────────────────────────────────────────────

class StoreFeedStatus(BaseModel):
    store_id: str
    last_event_at: Optional[str]
    lag_seconds: Optional[float]
    status: str   # "OK" | "STALE_FEED" | "NO_DATA"


class HealthResponse(BaseModel):
    status: str   # "healthy" | "degraded"
    version: str
    checked_at: str
    database: str   # "ok" | "unavailable"
    stores: List[StoreFeedStatus]
    uptime_seconds: float


# ── Error responses ────────────────────────────────────────────────────────────

class ErrorResponse(BaseModel):
    error: str
    detail: Optional[Any] = None
    trace_id: Optional[str] = None
