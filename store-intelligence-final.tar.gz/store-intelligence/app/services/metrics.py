"""
services/metrics.py — Real-time store metric computation.

All queries are real-time against the events table — no caching.
Metrics window defaults to current calendar day (store local time = UTC for now).

Conversion rate calculation:
  A visitor session is "converted" if their visitor_id appears in the billing zone
  within the 5-minute window before any POS transaction at the same store.
  Correlation: time-window join, not customer ID.

Staff exclusion:
  All queries filter WHERE is_staff = 0.

Re-entry dedup:
  Unique visitor count uses COUNT(DISTINCT visitor_id) across ENTRY events.
  REENTRY events do NOT generate a new ENTRY, so the count is naturally correct.
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import List, Optional

from app.db.database import get_db
from app.models import StoreMetrics, ZoneDwellMetric

log = logging.getLogger("metrics")

# Conversion correlation window — billing zone visit must precede transaction by ≤ this
CONVERSION_WINDOW_SEC = 300  # 5 minutes


async def get_store_metrics(store_id: str, window_hours: int = 24) -> StoreMetrics:
    """
    Compute real-time metrics for a store over the last N hours.
    """
    now = datetime.now(timezone.utc)
    window_start = now - timedelta(hours=window_hours)
    window_start_str = window_start.strftime("%Y-%m-%dT%H:%M:%SZ")
    now_str = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    async with get_db() as db:

        # ── Unique visitors (customer ENTRY events, not staff, not re-entries) ──
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as cnt
            FROM events
            WHERE store_id = ?
              AND event_type = 'ENTRY'
              AND is_staff = 0
              AND timestamp >= ?
              AND timestamp <= ?
        """, (store_id, window_start_str, now_str))).fetchone()
        unique_visitors = row["cnt"] if row else 0

        # ── Conversion rate ────────────────────────────────────────────────────
        # Visitors who were in billing zone within 5 min before a transaction
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT e.visitor_id) as converted
            FROM events e
            INNER JOIN pos_transactions p
                ON p.store_id = e.store_id
               AND e.zone_id LIKE '%BILLING%'
               AND e.is_staff = 0
               AND datetime(p.timestamp) >= datetime(e.timestamp)
               AND (julianday(p.timestamp) - julianday(e.timestamp)) * 86400 <= ?
            WHERE e.store_id = ?
              AND e.timestamp >= ?
              AND e.timestamp <= ?
        """, (CONVERSION_WINDOW_SEC, store_id, window_start_str, now_str))).fetchone()
        converted = row["converted"] if row else 0

        conversion_rate = (converted / unique_visitors) if unique_visitors > 0 else 0.0

        # ── Average dwell per zone ──────────────────────────────────────────────
        rows = await (await db.execute("""
            SELECT zone_id,
                   AVG(dwell_ms) as avg_dwell,
                   COUNT(*) as visit_count
            FROM events
            WHERE store_id = ?
              AND event_type IN ('ZONE_EXIT', 'ZONE_DWELL')
              AND is_staff = 0
              AND zone_id IS NOT NULL
              AND timestamp >= ?
              AND timestamp <= ?
            GROUP BY zone_id
            ORDER BY avg_dwell DESC
        """, (store_id, window_start_str, now_str))).fetchall()

        zone_dwells = [
            ZoneDwellMetric(
                zone_id=r["zone_id"],
                avg_dwell_ms=round(r["avg_dwell"] or 0, 1),
                visit_count=r["visit_count"],
            )
            for r in rows
        ]

        # ── Current queue depth (billing zone active visitors) ─────────────────
        # Count visitors with a BILLING zone ZONE_ENTER but no subsequent ZONE_EXIT
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as depth
            FROM events
            WHERE store_id = ?
              AND event_type = 'ZONE_ENTER'
              AND zone_id LIKE '%BILLING%'
              AND is_staff = 0
              AND timestamp >= ?
              AND visitor_id NOT IN (
                  SELECT DISTINCT visitor_id
                  FROM events
                  WHERE store_id = ?
                    AND event_type IN ('ZONE_EXIT', 'EXIT')
                    AND timestamp >= ?
                    AND timestamp <= ?
              )
        """, (store_id, window_start_str, store_id, window_start_str, now_str))).fetchone()
        queue_depth = row["depth"] if row else 0

        # ── Abandonment rate ───────────────────────────────────────────────────
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as abandoned
            FROM events
            WHERE store_id = ?
              AND event_type = 'BILLING_QUEUE_ABANDON'
              AND is_staff = 0
              AND timestamp >= ?
              AND timestamp <= ?
        """, (store_id, window_start_str, now_str))).fetchone()
        abandoned = row["abandoned"] if row else 0

        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as joined
            FROM events
            WHERE store_id = ?
              AND event_type IN ('BILLING_QUEUE_JOIN', 'ZONE_ENTER')
              AND zone_id LIKE '%BILLING%'
              AND is_staff = 0
              AND timestamp >= ?
              AND timestamp <= ?
        """, (store_id, window_start_str, now_str))).fetchone()
        billing_entered = row["joined"] if row else 0

        abandonment_rate = (abandoned / billing_entered) if billing_entered > 0 else 0.0

        # ── Total transactions ─────────────────────────────────────────────────
        row = await (await db.execute("""
            SELECT COUNT(*) as cnt FROM pos_transactions
            WHERE store_id = ? AND timestamp >= ? AND timestamp <= ?
        """, (store_id, window_start_str, now_str))).fetchone()
        total_transactions = row["cnt"] if row else 0

    # Data confidence: flag if fewer than 20 sessions
    data_confidence = "HIGH" if unique_visitors >= 20 else "LOW"

    return StoreMetrics(
        store_id=store_id,
        window_start=window_start_str,
        window_end=now_str,
        unique_visitors=unique_visitors,
        conversion_rate=round(conversion_rate, 4),
        avg_dwell_per_zone=zone_dwells,
        queue_depth=queue_depth,
        abandonment_rate=round(abandonment_rate, 4),
        total_transactions=total_transactions,
        data_confidence=data_confidence,
    )
