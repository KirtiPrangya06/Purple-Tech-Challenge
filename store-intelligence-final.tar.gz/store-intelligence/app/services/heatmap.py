"""
services/heatmap.py — Zone visit frequency + average dwell, normalised 0–100.

The heatmap shows where customers spend time in the store.
High score = high visit frequency AND high dwell time.
Normalisation: each zone's raw score = visit_count * log(1 + avg_dwell_ms)
               then scaled to 0–100 relative to max zone in the window.
"""

import logging
import math
from datetime import datetime, timezone, timedelta

from app.db.database import get_db
from app.models import StoreHeatmap, HeatmapZone

log = logging.getLogger("heatmap")


async def get_store_heatmap(store_id: str, window_hours: int = 24) -> StoreHeatmap:
    """Compute zone heatmap for a store."""
    now = datetime.now(timezone.utc)
    window_start = now - timedelta(hours=window_hours)
    window_start_str = window_start.strftime("%Y-%m-%dT%H:%M:%SZ")
    now_str = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    async with get_db() as db:
        rows = await (await db.execute("""
            SELECT
                zone_id,
                sku_zone,
                COUNT(DISTINCT visitor_id) as visit_frequency,
                AVG(CASE WHEN dwell_ms > 0 THEN dwell_ms ELSE NULL END) as avg_dwell_ms,
                COUNT(*) as event_count
            FROM events
            WHERE store_id = ?
              AND event_type IN ('ZONE_ENTER', 'ZONE_DWELL', 'ZONE_EXIT')
              AND is_staff = 0
              AND zone_id IS NOT NULL
              AND timestamp >= ?
              AND timestamp <= ?
            GROUP BY zone_id
            ORDER BY visit_frequency DESC
        """, (store_id, window_start_str, now_str))).fetchall()

        # Total unique visitors for confidence check
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as cnt
            FROM events
            WHERE store_id = ? AND event_type = 'ENTRY'
              AND is_staff = 0 AND timestamp >= ? AND timestamp <= ?
        """, (store_id, window_start_str, now_str))).fetchone()
        session_count = row["cnt"] if row else 0

    if not rows:
        return StoreHeatmap(
            store_id=store_id,
            window_start=window_start_str,
            window_end=now_str,
            zones=[],
            data_confidence="LOW",
        )

    # Compute raw scores
    zone_data = []
    for r in rows:
        freq = r["visit_frequency"] or 0
        avg_dwell = r["avg_dwell_ms"] or 0
        raw_score = freq * math.log1p(avg_dwell)
        zone_data.append({
            "zone_id": r["zone_id"],
            "sku_zone": r["sku_zone"],
            "visit_frequency": freq,
            "avg_dwell_ms": round(avg_dwell, 1),
            "raw_score": raw_score,
        })

    max_score = max(z["raw_score"] for z in zone_data) if zone_data else 1.0

    zones = [
        HeatmapZone(
            zone_id=z["zone_id"],
            visit_frequency=z["visit_frequency"],
            avg_dwell_ms=z["avg_dwell_ms"],
            normalised_score=round((z["raw_score"] / max_score) * 100, 1) if max_score > 0 else 0.0,
            sku_zone=z["sku_zone"],
        )
        for z in zone_data
    ]

    data_confidence = "HIGH" if session_count >= 20 else "LOW"

    return StoreHeatmap(
        store_id=store_id,
        window_start=window_start_str,
        window_end=now_str,
        zones=zones,
        data_confidence=data_confidence,
    )
