"""
services/health.py — Service health check.

Reports:
  - Database connectivity
  - Last event timestamp per store
  - STALE_FEED warning if any store hasn't sent events in >10 minutes
  - API uptime

This is what an on-call engineer checks first — must be accurate and fast.
"""

import logging
import time
from datetime import datetime, timezone, timedelta
from typing import List

from app.db.database import get_db, check_db_health
from app.models import HealthResponse, StoreFeedStatus

log = logging.getLogger("health")

API_VERSION = "1.0.0"
STALE_FEED_MINUTES = 10

# Module-level start time for uptime calculation
_start_time = time.time()


async def get_health() -> HealthResponse:
    """Return full health status of the service."""
    now = datetime.now(timezone.utc)
    now_str = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    stale_cutoff = (now - timedelta(minutes=STALE_FEED_MINUTES)).strftime("%Y-%m-%dT%H:%M:%SZ")

    db_ok = await check_db_health()
    store_statuses: List[StoreFeedStatus] = []

    if db_ok:
        try:
            async with get_db() as db:
                rows = await (await db.execute("""
                    SELECT store_id, MAX(timestamp) as last_event
                    FROM events
                    GROUP BY store_id
                    ORDER BY store_id
                """)).fetchall()

            for row in rows:
                store_id = row["store_id"]
                last_event = row["last_event"]

                if last_event is None:
                    store_statuses.append(StoreFeedStatus(
                        store_id=store_id,
                        last_event_at=None,
                        lag_seconds=None,
                        status="NO_DATA",
                    ))
                else:
                    last_dt = datetime.fromisoformat(last_event.replace("Z", "+00:00"))
                    lag_sec = (now - last_dt).total_seconds()
                    status = "STALE_FEED" if last_event < stale_cutoff else "OK"
                    store_statuses.append(StoreFeedStatus(
                        store_id=store_id,
                        last_event_at=last_event,
                        lag_seconds=round(lag_sec, 1),
                        status=status,
                    ))
        except Exception as e:
            log.error(f"Health check DB query failed: {e}")
            db_ok = False

    overall_status = "healthy"
    if not db_ok:
        overall_status = "degraded"
    elif any(s.status == "STALE_FEED" for s in store_statuses):
        overall_status = "degraded"

    return HealthResponse(
        status=overall_status,
        version=API_VERSION,
        checked_at=now_str,
        database="ok" if db_ok else "unavailable",
        stores=store_statuses,
        uptime_seconds=round(time.time() - _start_time, 1),
    )
