"""
services/ingestion.py — Ingest, deduplicate, and persist events.

Idempotency guarantee:
  - event_id is the PRIMARY KEY — inserting duplicate is silently ignored
  - INSERT OR IGNORE handles concurrent duplicate submissions safely
  - Partial success: malformed events return errors, valid events are stored

Batch handling:
  - Up to 500 events per request (enforced by Pydantic model)
  - Single transaction per batch for atomicity
  - Returns per-event errors for malformed payloads
"""

import logging
from typing import List, Tuple

from app.db.database import get_db
from app.models import StoreEvent, IngestResponse, EventError

log = logging.getLogger("ingestion")

INSERT_EVENT_SQL = """
INSERT OR IGNORE INTO events (
    event_id, store_id, camera_id, visitor_id, event_type,
    timestamp, zone_id, dwell_ms, is_staff, confidence,
    queue_depth, sku_zone, session_seq
) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
"""


async def ingest_events(events: List[StoreEvent]) -> IngestResponse:
    """
    Persist a batch of events. Returns counts of ingested, duplicates, errors.
    """
    rows = []
    errors: List[EventError] = []

    for idx, event in enumerate(events):
        try:
            row = (
                event.event_id,
                event.store_id,
                event.camera_id,
                event.visitor_id,
                event.event_type.value,
                event.timestamp,
                event.zone_id,
                event.dwell_ms,
                1 if event.is_staff else 0,
                event.confidence,
                event.metadata.queue_depth,
                event.metadata.sku_zone,
                event.metadata.session_seq,
            )
            rows.append((idx, row))
        except Exception as e:
            errors.append(EventError(
                event_id=getattr(event, "event_id", None),
                index=idx,
                error=str(e),
            ))

    ingested = 0
    duplicates = 0

    async with get_db() as db:
        for idx, row in rows:
            try:
                cursor = await db.execute(INSERT_EVENT_SQL, row)
                if cursor.rowcount == 1:
                    ingested += 1
                else:
                    duplicates += 1
            except Exception as e:
                log.warning(f"Event insert failed at index {idx}: {e}")
                errors.append(EventError(
                    event_id=row[0],
                    index=idx,
                    error=str(e),
                ))
        await db.commit()

    status = "ok" if not errors else "partial"
    log.info(f"Ingest: {ingested} stored, {duplicates} dupes, {len(errors)} errors")

    return IngestResponse(
        ingested=ingested,
        duplicates=duplicates,
        errors=len(errors),
        error_details=errors,
        status=status,
    )


async def ingest_pos_transactions(transactions: list) -> tuple[int, int]:
    """Ingest POS transactions from CSV rows. Returns (inserted, duplicates)."""
    INSERT_POS = """
    INSERT OR IGNORE INTO pos_transactions (transaction_id, store_id, timestamp, basket_value)
    VALUES (?, ?, ?, ?)
    """
    inserted = 0
    duplicates = 0
    async with get_db() as db:
        for txn in transactions:
            try:
                cursor = await db.execute(INSERT_POS, (
                    txn.get("transaction_id"),
                    txn.get("store_id"),
                    txn.get("timestamp"),
                    float(txn.get("basket_value_inr", txn.get("basket_value", 0))),
                ))
                if cursor.rowcount == 1:
                    inserted += 1
                else:
                    duplicates += 1
            except Exception as e:
                log.warning(f"POS insert failed: {e}")
        await db.commit()
    return inserted, duplicates
