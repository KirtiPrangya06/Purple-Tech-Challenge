"""
services/anomalies.py — Real-time anomaly detection for store operations.

Anomaly types:
  BILLING_QUEUE_SPIKE  — current queue depth > configured threshold
  CONVERSION_DROP      — today's conversion rate < (7-day average * threshold)
  DEAD_ZONE            — named zone has had no visits in last 30 minutes
  STALE_FEED           — no events from a store in last 10 minutes
  EMPTY_STORE          — store has been open but no visitors in last 30 minutes

Severity rules:
  INFO     — informational, no immediate action needed
  WARN     — degraded performance, should investigate
  CRITICAL — immediate action recommended
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import List

from app.db.database import get_db
from app.models import Anomaly, AnomalyResponse, AnomalySeverity, AnomalyType

log = logging.getLogger("anomalies")

# Thresholds
QUEUE_SPIKE_WARN = 5          # ≥5 people in billing = WARN
QUEUE_SPIKE_CRITICAL = 10     # ≥10 people = CRITICAL
CONVERSION_DROP_WARN = 0.80   # conversion < 80% of 7-day avg = WARN
CONVERSION_DROP_CRITICAL = 0.50  # conversion < 50% of 7-day avg = CRITICAL
DEAD_ZONE_MINUTES = 30
STALE_FEED_MINUTES = 10
EMPTY_STORE_MINUTES = 30


async def get_store_anomalies(store_id: str) -> AnomalyResponse:
    """Detect and return active anomalies for a store."""
    now = datetime.now(timezone.utc)
    now_str = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    anomalies: List[Anomaly] = []

    async with get_db() as db:

        # ── 1. STALE_FEED ──────────────────────────────────────────────────────
        stale_cutoff = (now - timedelta(minutes=STALE_FEED_MINUTES)).strftime("%Y-%m-%dT%H:%M:%SZ")
        row = await (await db.execute("""
            SELECT MAX(timestamp) as last_event FROM events
            WHERE store_id = ?
        """, (store_id,))).fetchone()

        last_event = row["last_event"] if row else None
        if last_event is None:
            anomalies.append(Anomaly(
                anomaly_type=AnomalyType.STALE_FEED,
                severity=AnomalySeverity.WARN,
                store_id=store_id,
                detected_at=now_str,
                description=f"No events received for store {store_id}.",
                suggested_action="Check camera connectivity and pipeline status.",
                metric_value=None,
                threshold_value=float(STALE_FEED_MINUTES),
            ))
        elif last_event < stale_cutoff:
            from datetime import datetime as dt
            last_dt = dt.fromisoformat(last_event.replace("Z", "+00:00"))
            lag_min = (now - last_dt).total_seconds() / 60
            anomalies.append(Anomaly(
                anomaly_type=AnomalyType.STALE_FEED,
                severity=AnomalySeverity.CRITICAL if lag_min > 30 else AnomalySeverity.WARN,
                store_id=store_id,
                detected_at=now_str,
                description=f"No events received in {lag_min:.0f} minutes (last: {last_event}).",
                suggested_action="Check camera connectivity, pipeline health, and network. Restart detect.py if needed.",
                metric_value=round(lag_min, 1),
                threshold_value=float(STALE_FEED_MINUTES),
            ))

        # ── 2. BILLING_QUEUE_SPIKE ─────────────────────────────────────────────
        window_1h = (now - timedelta(hours=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as depth
            FROM events
            WHERE store_id = ?
              AND event_type = 'ZONE_ENTER'
              AND zone_id LIKE '%BILLING%'
              AND is_staff = 0
              AND timestamp >= ?
              AND visitor_id NOT IN (
                  SELECT DISTINCT visitor_id FROM events
                  WHERE store_id = ?
                    AND event_type IN ('ZONE_EXIT', 'EXIT')
                    AND timestamp >= ?
              )
        """, (store_id, window_1h, store_id, window_1h))).fetchone()
        queue_depth = row["depth"] if row else 0

        if queue_depth >= QUEUE_SPIKE_CRITICAL:
            anomalies.append(Anomaly(
                anomaly_type=AnomalyType.BILLING_QUEUE_SPIKE,
                severity=AnomalySeverity.CRITICAL,
                store_id=store_id,
                detected_at=now_str,
                description=f"Billing queue has {queue_depth} customers — critically high.",
                suggested_action="Open additional checkout counters immediately. Alert floor manager.",
                metric_value=float(queue_depth),
                threshold_value=float(QUEUE_SPIKE_CRITICAL),
            ))
        elif queue_depth >= QUEUE_SPIKE_WARN:
            anomalies.append(Anomaly(
                anomaly_type=AnomalyType.BILLING_QUEUE_SPIKE,
                severity=AnomalySeverity.WARN,
                store_id=store_id,
                detected_at=now_str,
                description=f"Billing queue has {queue_depth} customers.",
                suggested_action="Consider opening an additional checkout counter.",
                metric_value=float(queue_depth),
                threshold_value=float(QUEUE_SPIKE_WARN),
            ))

        # ── 3. CONVERSION_DROP ─────────────────────────────────────────────────
        # Today's conversion vs 7-day average
        today_start = now.replace(hour=0, minute=0, second=0, microsecond=0).strftime("%Y-%m-%dT%H:%M:%SZ")
        week_start = (now - timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")

        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as visitors
            FROM events
            WHERE store_id = ? AND event_type = 'ENTRY'
              AND is_staff = 0 AND timestamp >= ? AND timestamp <= ?
        """, (store_id, today_start, now_str))).fetchone()
        today_visitors = row["visitors"] if row else 0

        row = await (await db.execute("""
            SELECT COUNT(DISTINCT e.visitor_id) as converted
            FROM events e
            INNER JOIN pos_transactions p
                ON p.store_id = e.store_id
               AND e.zone_id LIKE '%BILLING%'
               AND e.is_staff = 0
               AND datetime(p.timestamp) >= datetime(e.timestamp)
               AND (julianday(p.timestamp) - julianday(e.timestamp)) * 86400 <= 300
            WHERE e.store_id = ? AND e.timestamp >= ? AND e.timestamp <= ?
        """, (store_id, today_start, now_str))).fetchone()
        today_converted = row["converted"] if row else 0

        today_rate = (today_converted / today_visitors) if today_visitors > 0 else None

        # 7-day average (exclude today)
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as visitors
            FROM events
            WHERE store_id = ? AND event_type = 'ENTRY'
              AND is_staff = 0 AND timestamp >= ? AND timestamp < ?
        """, (store_id, week_start, today_start))).fetchone()
        week_visitors = row["visitors"] if row else 0

        row = await (await db.execute("""
            SELECT COUNT(DISTINCT e.visitor_id) as converted
            FROM events e
            INNER JOIN pos_transactions p
                ON p.store_id = e.store_id
               AND e.zone_id LIKE '%BILLING%'
               AND e.is_staff = 0
               AND datetime(p.timestamp) >= datetime(e.timestamp)
               AND (julianday(p.timestamp) - julianday(e.timestamp)) * 86400 <= 300
            WHERE e.store_id = ? AND e.timestamp >= ? AND e.timestamp < ?
        """, (store_id, week_start, today_start))).fetchone()
        week_converted = row["converted"] if row else 0

        week_rate = (week_converted / week_visitors) if week_visitors > 0 else None

        if today_rate is not None and week_rate is not None and week_rate > 0:
            ratio = today_rate / week_rate
            if ratio < CONVERSION_DROP_CRITICAL:
                anomalies.append(Anomaly(
                    anomaly_type=AnomalyType.CONVERSION_DROP,
                    severity=AnomalySeverity.CRITICAL,
                    store_id=store_id,
                    detected_at=now_str,
                    description=f"Conversion rate {today_rate:.1%} is {(1-ratio):.0%} below 7-day average {week_rate:.1%}.",
                    suggested_action="Urgently review today's promotions, pricing, and staff engagement. Escalate to store manager.",
                    metric_value=round(today_rate, 4),
                    threshold_value=round(week_rate * CONVERSION_DROP_CRITICAL, 4),
                ))
            elif ratio < CONVERSION_DROP_WARN:
                anomalies.append(Anomaly(
                    anomaly_type=AnomalyType.CONVERSION_DROP,
                    severity=AnomalySeverity.WARN,
                    store_id=store_id,
                    detected_at=now_str,
                    description=f"Conversion rate {today_rate:.1%} is below 7-day average {week_rate:.1%}.",
                    suggested_action="Review promotions and staff engagement in high-dwell zones.",
                    metric_value=round(today_rate, 4),
                    threshold_value=round(week_rate * CONVERSION_DROP_WARN, 4),
                ))

        # ── 4. DEAD_ZONE ───────────────────────────────────────────────────────
        dead_cutoff = (now - timedelta(minutes=DEAD_ZONE_MINUTES)).strftime("%Y-%m-%dT%H:%M:%SZ")

        # Get all zones that had activity in the last 24h
        all_zones = await (await db.execute("""
            SELECT DISTINCT zone_id FROM events
            WHERE store_id = ? AND zone_id IS NOT NULL
              AND timestamp >= ?
        """, (store_id, (now - timedelta(hours=24)).strftime("%Y-%m-%dT%H:%M:%SZ")))).fetchall()

        for zone_row in all_zones:
            zone_id = zone_row["zone_id"]
            row = await (await db.execute("""
                SELECT COUNT(*) as cnt FROM events
                WHERE store_id = ? AND zone_id = ?
                  AND event_type IN ('ZONE_ENTER', 'ZONE_DWELL')
                  AND is_staff = 0
                  AND timestamp >= ?
            """, (store_id, zone_id, dead_cutoff))).fetchone()
            recent_visits = row["cnt"] if row else 0

            if recent_visits == 0:
                anomalies.append(Anomaly(
                    anomaly_type=AnomalyType.DEAD_ZONE,
                    severity=AnomalySeverity.INFO,
                    store_id=store_id,
                    zone_id=zone_id,
                    detected_at=now_str,
                    description=f"Zone '{zone_id}' has had no customer visits in {DEAD_ZONE_MINUTES} minutes.",
                    suggested_action=f"Check zone '{zone_id}' for display issues, stock-outs, or blocked access.",
                    metric_value=0.0,
                    threshold_value=float(DEAD_ZONE_MINUTES),
                ))

    return AnomalyResponse(
        store_id=store_id,
        active_anomalies=anomalies,
        checked_at=now_str,
    )
