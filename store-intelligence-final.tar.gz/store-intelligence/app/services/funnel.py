"""
services/funnel.py — Conversion funnel computation.

Funnel stages:
  1. Entry          — unique visitors who entered the store
  2. Zone Visit     — visitors who entered at least one named zone
  3. Billing Queue  — visitors who entered the billing/checkout zone
  4. Purchase       — visitors whose billing visit correlates to a POS transaction

Session is the unit — re-entries do NOT double-count a visitor.
Drop-off % = (prev_stage - current_stage) / prev_stage * 100
"""

import logging
from datetime import datetime, timezone, timedelta

from app.db.database import get_db
from app.models import StoreFunnel, FunnelStage

log = logging.getLogger("funnel")

CONVERSION_WINDOW_SEC = 300  # must match metrics.py


async def get_store_funnel(store_id: str, window_hours: int = 24) -> StoreFunnel:
    """Compute the conversion funnel for a store over the last N hours."""
    now = datetime.now(timezone.utc)
    window_start = now - timedelta(hours=window_hours)
    window_start_str = window_start.strftime("%Y-%m-%dT%H:%M:%SZ")
    now_str = now.strftime("%Y-%m-%dT%H:%M:%SZ")

    async with get_db() as db:

        # Stage 1: Unique customer visitors (ENTRY events, no staff, no re-entry double-count)
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as cnt
            FROM events
            WHERE store_id = ?
              AND event_type = 'ENTRY'
              AND is_staff = 0
              AND timestamp >= ?
              AND timestamp <= ?
        """, (store_id, window_start_str, now_str))).fetchone()
        stage_entry = row["cnt"] if row else 0

        # Stage 2: Visitors who entered at least one named zone
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as cnt
            FROM events
            WHERE store_id = ?
              AND event_type = 'ZONE_ENTER'
              AND is_staff = 0
              AND zone_id IS NOT NULL
              AND timestamp >= ?
              AND timestamp <= ?
              AND visitor_id IN (
                  SELECT DISTINCT visitor_id FROM events
                  WHERE store_id = ? AND event_type = 'ENTRY' AND is_staff = 0
                    AND timestamp >= ? AND timestamp <= ?
              )
        """, (store_id, window_start_str, now_str,
               store_id, window_start_str, now_str))).fetchone()
        stage_zone_visit = row["cnt"] if row else 0

        # Stage 3: Visitors who entered billing zone
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT visitor_id) as cnt
            FROM events
            WHERE store_id = ?
              AND event_type = 'ZONE_ENTER'
              AND zone_id LIKE '%BILLING%'
              AND is_staff = 0
              AND timestamp >= ?
              AND timestamp <= ?
              AND visitor_id IN (
                  SELECT DISTINCT visitor_id FROM events
                  WHERE store_id = ? AND event_type = 'ENTRY' AND is_staff = 0
                    AND timestamp >= ? AND timestamp <= ?
              )
        """, (store_id, window_start_str, now_str,
               store_id, window_start_str, now_str))).fetchone()
        stage_billing = row["cnt"] if row else 0

        # Stage 4: Visitors who completed a purchase (billing visit + POS correlation)
        row = await (await db.execute("""
            SELECT COUNT(DISTINCT e.visitor_id) as cnt
            FROM events e
            INNER JOIN pos_transactions p
                ON p.store_id = e.store_id
               AND e.zone_id LIKE '%BILLING%'
               AND e.is_staff = 0
               AND datetime(p.timestamp) >= datetime(e.timestamp)
               AND (julianday(p.timestamp) - julianday(e.timestamp)) * 86400 <= ?
            WHERE e.store_id = ?
              AND e.timestamp >= ?
              AND e.timestamp <= ?
              AND e.visitor_id IN (
                  SELECT DISTINCT visitor_id FROM events
                  WHERE store_id = ? AND event_type = 'ENTRY' AND is_staff = 0
                    AND timestamp >= ? AND timestamp <= ?
              )
        """, (CONVERSION_WINDOW_SEC, store_id, window_start_str, now_str,
               store_id, window_start_str, now_str))).fetchone()
        stage_purchase = row["cnt"] if row else 0

    # Build funnel with drop-off percentages
    counts = [stage_entry, stage_zone_visit, stage_billing, stage_purchase]
    labels = ["Entry", "Zone Visit", "Billing Queue", "Purchase"]

    stages = []
    for i, (label, count) in enumerate(zip(labels, counts)):
        prev = counts[i - 1] if i > 0 else count
        drop_off = ((prev - count) / prev * 100) if prev > 0 else 0.0
        stages.append(FunnelStage(
            stage=label,
            count=count,
            drop_off_pct=round(drop_off, 2),
        ))

    return StoreFunnel(
        store_id=store_id,
        window_start=window_start_str,
        window_end=now_str,
        stages=stages,
        session_count=stage_entry,
    )
