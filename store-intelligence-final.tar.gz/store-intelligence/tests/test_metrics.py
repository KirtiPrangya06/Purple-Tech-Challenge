# PROMPT:
# "Write pytest tests for a FastAPI store analytics API with endpoints:
# POST /events/ingest, GET /stores/{id}/metrics, GET /stores/{id}/funnel.
# Test: idempotency (same payload twice returns same counts), partial success
# on malformed events, staff exclusion from metrics, re-entry dedup in funnel,
# zero-purchase store returns 0.0 conversion rate (not null/error),
# empty store returns valid response with zero visitors.
# Use httpx.AsyncClient with ASGITransport for async tests."
#
# CHANGES MADE:
# - AI generated synchronous TestClient usage — switched to async httpx for accuracy
# - Added test_ingest_idempotency which AI forgot to include despite being in the spec
# - AI's conversion rate test used a shortcut — replaced with proper POS correlation test
# - Added all-staff-clip edge case test (AI initially omitted)

import pytest
import pytest_asyncio
import json
import uuid
from datetime import datetime, timezone, timedelta
from httpx import AsyncClient, ASGITransport

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))


@pytest.fixture(scope="session")
def event_loop_policy():
    import asyncio
    return asyncio.DefaultEventLoopPolicy()


@pytest_asyncio.fixture
async def client(tmp_path, monkeypatch):
    """Async test client with isolated in-memory DB."""
    db_file = str(tmp_path / "test.db")
    monkeypatch.setenv("DATABASE_URL", db_file)

    # Re-import after env set
    import importlib
    import app.db.database as db_mod
    db_mod.DB_PATH = db_file
    importlib.reload(db_mod)

    from app.main import app
    from app.db.database import init_db
    await init_db(db_file)

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


STORE_ID = "STORE_BLR_002"


def make_event(
    event_type="ENTRY",
    visitor_id=None,
    store_id=STORE_ID,
    zone_id=None,
    is_staff=False,
    confidence=0.85,
    dwell_ms=0,
):
    return {
        "event_id": str(uuid.uuid4()),
        "store_id": store_id,
        "camera_id": "CAM_ENTRY_01",
        "visitor_id": visitor_id or f"VIS_{uuid.uuid4().hex[:6]}",
        "event_type": event_type,
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "zone_id": zone_id,
        "dwell_ms": dwell_ms,
        "is_staff": is_staff,
        "confidence": confidence,
        "metadata": {"queue_depth": None, "sku_zone": zone_id, "session_seq": 1},
    }


# ── Ingest endpoint ────────────────────────────────────────────────────────────

class TestIngest:

    @pytest.mark.asyncio
    async def test_ingest_returns_200(self, client):
        payload = {"events": [make_event()]}
        resp = await client.post("/events/ingest", json=payload)
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_ingest_response_schema(self, client):
        payload = {"events": [make_event()]}
        resp = await client.post("/events/ingest", json=payload)
        data = resp.json()
        assert "ingested" in data
        assert "duplicates" in data
        assert "errors" in data
        assert "status" in data

    @pytest.mark.asyncio
    async def test_ingest_idempotency(self, client):
        """Posting same payload twice must not double-count events."""
        event = make_event()
        payload = {"events": [event]}

        resp1 = await client.post("/events/ingest", json=payload)
        resp2 = await client.post("/events/ingest", json=payload)

        data1 = resp1.json()
        data2 = resp2.json()

        assert data1["ingested"] == 1
        assert data2["ingested"] == 0
        assert data2["duplicates"] == 1

    @pytest.mark.asyncio
    async def test_ingest_partial_success_on_malformed(self, client):
        """Valid events ingest, malformed events return errors — not 5xx."""
        valid = make_event()
        malformed = {
            "event_id": "not-a-uuid",   # invalid UUID
            "store_id": STORE_ID,
            "camera_id": "CAM_ENTRY_01",
            "visitor_id": "VIS_abc",
            "event_type": "ENTRY",
            "timestamp": "not-a-timestamp",  # invalid
            "confidence": 2.0,               # out of range
            "dwell_ms": 0,
            "is_staff": False,
            "metadata": {},
        }
        payload = {"events": [valid, malformed]}
        resp = await client.post("/events/ingest", json=payload)
        # Should not 5xx — partial success
        assert resp.status_code in (200, 207, 422)

    @pytest.mark.asyncio
    async def test_ingest_batch_up_to_500(self, client):
        events = [make_event() for _ in range(500)]
        payload = {"events": events}
        resp = await client.post("/events/ingest", json=payload)
        assert resp.status_code == 200
        data = resp.json()
        assert data["ingested"] == 500

    @pytest.mark.asyncio
    async def test_ingest_rejects_batch_over_500(self, client):
        events = [make_event() for _ in range(501)]
        payload = {"events": events}
        resp = await client.post("/events/ingest", json=payload)
        assert resp.status_code == 422  # Pydantic validation error


# ── Metrics endpoint ───────────────────────────────────────────────────────────

class TestMetrics:

    @pytest.mark.asyncio
    async def test_metrics_returns_200(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/metrics")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_metrics_zero_visitors_store(self, client):
        """Empty store must return zero metrics — not crash or return null."""
        resp = await client.get(f"/stores/STORE_EMPTY_999/metrics")
        assert resp.status_code == 200
        data = resp.json()
        assert data["unique_visitors"] == 0
        assert data["conversion_rate"] == 0.0
        assert data["queue_depth"] == 0
        assert data["abandonment_rate"] == 0.0

    @pytest.mark.asyncio
    async def test_metrics_excludes_staff(self, client):
        """Staff events must not count toward unique_visitors."""
        staff_event = make_event(is_staff=True)
        customer_event = make_event(is_staff=False)
        await client.post("/events/ingest", json={"events": [staff_event, customer_event]})

        resp = await client.get(f"/stores/{STORE_ID}/metrics")
        data = resp.json()
        # Only customer counts — staff excluded
        assert data["unique_visitors"] >= 1

    @pytest.mark.asyncio
    async def test_metrics_all_staff_clip_zero_visitors(self, client):
        """All-staff clip edge case: unique_visitors = 0, not staff count."""
        store_id = "STORE_STAFF_ONLY"
        events = [make_event(is_staff=True, store_id=store_id) for _ in range(10)]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/metrics")
        assert resp.status_code == 200
        data = resp.json()
        assert data["unique_visitors"] == 0

    @pytest.mark.asyncio
    async def test_metrics_zero_purchases_conversion_is_zero(self, client):
        """Zero purchases → conversion_rate = 0.0, not null, not error."""
        store_id = "STORE_NOPURCHASE"
        events = [make_event(store_id=store_id) for _ in range(5)]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/metrics")
        assert resp.status_code == 200
        data = resp.json()
        assert data["conversion_rate"] == 0.0
        assert isinstance(data["conversion_rate"], float)

    @pytest.mark.asyncio
    async def test_metrics_response_schema(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/metrics")
        data = resp.json()
        required = [
            "store_id", "window_start", "window_end", "unique_visitors",
            "conversion_rate", "avg_dwell_per_zone", "queue_depth",
            "abandonment_rate", "total_transactions", "data_confidence",
        ]
        for field in required:
            assert field in data, f"Missing field in metrics response: {field}"

    @pytest.mark.asyncio
    async def test_metrics_data_confidence_low_under_20_sessions(self, client):
        store_id = "STORE_FEW_VISITORS"
        # Ingest only 5 visitors
        events = [make_event(store_id=store_id) for _ in range(5)]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/metrics")
        data = resp.json()
        assert data["data_confidence"] == "LOW"


# ── Funnel endpoint ────────────────────────────────────────────────────────────

class TestFunnel:

    @pytest.mark.asyncio
    async def test_funnel_returns_200(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/funnel")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_funnel_has_four_stages(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/funnel")
        data = resp.json()
        assert "stages" in data
        assert len(data["stages"]) == 4

    @pytest.mark.asyncio
    async def test_funnel_stage_counts_descending(self, client):
        """Each funnel stage must have count ≤ previous stage."""
        store_id = "STORE_FUNNEL_TEST"
        vid1 = f"VIS_{uuid.uuid4().hex[:6]}"
        vid2 = f"VIS_{uuid.uuid4().hex[:6]}"

        events = [
            make_event(event_type="ENTRY", visitor_id=vid1, store_id=store_id),
            make_event(event_type="ENTRY", visitor_id=vid2, store_id=store_id),
            make_event(event_type="ZONE_ENTER", visitor_id=vid1, store_id=store_id, zone_id="SKINCARE"),
        ]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/funnel")
        data = resp.json()
        counts = [s["count"] for s in data["stages"]]
        for i in range(1, len(counts)):
            assert counts[i] <= counts[i - 1], f"Stage {i} count exceeds stage {i-1}"

    @pytest.mark.asyncio
    async def test_funnel_reentry_does_not_double_count(self, client):
        """A visitor with ENTRY + REENTRY must count as 1 in the funnel, not 2."""
        store_id = "STORE_REENTRY_TEST"
        vid = f"VIS_{uuid.uuid4().hex[:6]}"
        now = datetime.now(timezone.utc)

        events = [
            # First visit — ENTRY
            make_event(event_type="ENTRY", visitor_id=vid, store_id=store_id),
            # Re-entry after returning — same visitor_id, REENTRY event
            # funnel counts DISTINCT visitor_id on ENTRY events only
            # REENTRY does NOT add another ENTRY → count stays 1
            make_event(event_type="REENTRY", visitor_id=vid, store_id=store_id),
        ]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/funnel")
        data = resp.json()
        entry_stage = next(s for s in data["stages"] if s["stage"] == "Entry")
        # Only 1 ENTRY event for this visitor → count must be 1
        assert entry_stage["count"] == 1, "Re-entry must not inflate unique visitor count"

    @pytest.mark.asyncio
    async def test_funnel_drop_off_pct_range(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/funnel")
        data = resp.json()
        for stage in data["stages"]:
            assert 0.0 <= stage["drop_off_pct"] <= 100.0


# ── Health endpoint ────────────────────────────────────────────────────────────

class TestHealth:

    @pytest.mark.asyncio
    async def test_health_returns_200(self, client):
        resp = await client.get("/health")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_health_schema(self, client):
        resp = await client.get("/health")
        data = resp.json()
        assert "status" in data
        assert "database" in data
        assert "stores" in data
        assert "uptime_seconds" in data
        assert data["database"] == "ok"
