# PROMPT:
# "Write pytest tests for an anomaly detection service that detects:
# BILLING_QUEUE_SPIKE (>= 5 customers in billing = WARN, >= 10 = CRITICAL),
# CONVERSION_DROP (today's rate < 80% of 7-day average = WARN, < 50% = CRITICAL),
# DEAD_ZONE (no visits in 30 min = INFO),
# STALE_FEED (no events in 10 min = WARN, 30+ min = CRITICAL).
# Each anomaly must have severity, suggested_action, metric_value, threshold_value.
# Test empty store returns no anomalies except possibly STALE_FEED.
# Use isolated async DB per test via pytest fixtures."
#
# CHANGES MADE:
# - AI placed all anomaly tests in one class — split by anomaly type for clarity
# - AI's STALE_FEED test used time.sleep() — replaced with DB manipulation for speed
# - Added test that anomaly response has correct schema (AI omitted this)
# - Added suggested_action non-empty assertion (AI omitted)

import pytest
import pytest_asyncio
import uuid
from datetime import datetime, timezone, timedelta
from httpx import AsyncClient, ASGITransport

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

STORE_ID = "STORE_BLR_002"


def make_event(
    event_type="ENTRY",
    visitor_id=None,
    store_id=STORE_ID,
    zone_id=None,
    is_staff=False,
    confidence=0.85,
    dwell_ms=0,
    timestamp=None,
):
    return {
        "event_id": str(uuid.uuid4()),
        "store_id": store_id,
        "camera_id": "CAM_ENTRY_01",
        "visitor_id": visitor_id or f"VIS_{uuid.uuid4().hex[:6]}",
        "event_type": event_type,
        "timestamp": timestamp or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "zone_id": zone_id,
        "dwell_ms": dwell_ms,
        "is_staff": is_staff,
        "confidence": confidence,
        "metadata": {"queue_depth": None, "sku_zone": zone_id, "session_seq": 1},
    }


@pytest_asyncio.fixture
async def client(tmp_path, monkeypatch):
    db_file = str(tmp_path / "test_anomalies.db")
    monkeypatch.setenv("DATABASE_URL", db_file)

    import importlib
    import app.db.database as db_mod
    db_mod.DB_PATH = db_file
    importlib.reload(db_mod)

    from app.main import app
    from app.db.database import init_db
    await init_db(db_file)

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


# ── Response schema ────────────────────────────────────────────────────────────

class TestAnomalySchema:

    @pytest.mark.asyncio
    async def test_anomaly_endpoint_returns_200(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/anomalies")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_anomaly_response_schema(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/anomalies")
        data = resp.json()
        assert "store_id" in data
        assert "active_anomalies" in data
        assert "checked_at" in data
        assert isinstance(data["active_anomalies"], list)

    @pytest.mark.asyncio
    async def test_each_anomaly_has_required_fields(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/anomalies")
        data = resp.json()
        for anomaly in data["active_anomalies"]:
            assert "anomaly_type" in anomaly
            assert "severity" in anomaly
            assert "description" in anomaly
            assert "suggested_action" in anomaly
            assert anomaly["suggested_action"] != "", "suggested_action must not be empty"

    @pytest.mark.asyncio
    async def test_severity_values_are_valid(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/anomalies")
        data = resp.json()
        valid_severities = {"INFO", "WARN", "CRITICAL"}
        for anomaly in data["active_anomalies"]:
            assert anomaly["severity"] in valid_severities


# ── Stale feed ─────────────────────────────────────────────────────────────────

class TestStaleFeed:

    @pytest.mark.asyncio
    async def test_stale_feed_on_no_data(self, client):
        """Store with no events at all → STALE_FEED anomaly."""
        resp = await client.get(f"/stores/STORE_NEVER_SEEN/anomalies")
        data = resp.json()
        types = [a["anomaly_type"] for a in data["active_anomalies"]]
        assert "STALE_FEED" in types

    @pytest.mark.asyncio
    async def test_no_stale_feed_with_recent_events(self, client):
        """Store with events in last 10 min → no STALE_FEED."""
        store_id = "STORE_FRESH"
        events = [make_event(store_id=store_id)]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/anomalies")
        data = resp.json()
        types = [a["anomaly_type"] for a in data["active_anomalies"]]
        assert "STALE_FEED" not in types

    @pytest.mark.asyncio
    async def test_stale_feed_severity_warn_for_moderate_lag(self, client, tmp_path):
        """Stale feed between 10-30 min → WARN severity."""
        store_id = "STORE_STALE_WARN"
        # Insert an event 15 minutes ago directly via DB
        import aiosqlite
        import app.db.database as db_mod
        old_ts = (datetime.now(timezone.utc) - timedelta(minutes=15)).strftime("%Y-%m-%dT%H:%M:%SZ")
        async with aiosqlite.connect(db_mod.DB_PATH) as db:
            await db.execute("""
                INSERT OR IGNORE INTO events
                (event_id, store_id, camera_id, visitor_id, event_type, timestamp, dwell_ms, is_staff, confidence)
                VALUES (?, ?, 'CAM_ENTRY_01', 'VIS_test01', 'ENTRY', ?, 0, 0, 0.85)
            """, (str(uuid.uuid4()), store_id, old_ts))
            await db.commit()

        resp = await client.get(f"/stores/{store_id}/anomalies")
        data = resp.json()
        stale = [a for a in data["active_anomalies"] if a["anomaly_type"] == "STALE_FEED"]
        assert len(stale) == 1
        assert stale[0]["severity"] == "WARN"


# ── Billing queue spike ────────────────────────────────────────────────────────

class TestQueueSpike:

    @pytest.mark.asyncio
    async def test_queue_spike_warn_at_5_customers(self, client):
        store_id = "STORE_QUEUE_WARN"
        # 5 customers in billing zone simultaneously (no exit events)
        events = []
        for _ in range(5):
            vid = f"VIS_{uuid.uuid4().hex[:6]}"
            events.append(make_event(event_type="ENTRY", visitor_id=vid, store_id=store_id))
            events.append(make_event(
                event_type="ZONE_ENTER", visitor_id=vid, store_id=store_id,
                zone_id="BILLING",
            ))
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/anomalies")
        data = resp.json()
        queue_anomalies = [a for a in data["active_anomalies"] if a["anomaly_type"] == "BILLING_QUEUE_SPIKE"]
        assert len(queue_anomalies) >= 1
        assert queue_anomalies[0]["severity"] in ("WARN", "CRITICAL")

    @pytest.mark.asyncio
    async def test_no_queue_spike_with_few_customers(self, client):
        store_id = "STORE_QUEUE_NORMAL"
        # Only 2 customers in billing — below threshold
        events = []
        for _ in range(2):
            vid = f"VIS_{uuid.uuid4().hex[:6]}"
            events.append(make_event(event_type="ENTRY", visitor_id=vid, store_id=store_id))
            events.append(make_event(
                event_type="ZONE_ENTER", visitor_id=vid, store_id=store_id, zone_id="BILLING",
            ))
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/anomalies")
        data = resp.json()
        types = [a["anomaly_type"] for a in data["active_anomalies"]]
        assert "BILLING_QUEUE_SPIKE" not in types


# ── Dead zone ──────────────────────────────────────────────────────────────────

class TestDeadZone:

    @pytest.mark.asyncio
    async def test_dead_zone_detected_after_inactivity(self, client):
        store_id = "STORE_DEAD_ZONE"
        # Insert a zone visit 35 minutes ago
        import aiosqlite
        import app.db.database as db_mod
        old_ts = (datetime.now(timezone.utc) - timedelta(minutes=35)).strftime("%Y-%m-%dT%H:%M:%SZ")
        async with aiosqlite.connect(db_mod.DB_PATH) as db:
            await db.execute("""
                INSERT OR IGNORE INTO events
                (event_id, store_id, camera_id, visitor_id, event_type, timestamp, zone_id, dwell_ms, is_staff, confidence)
                VALUES (?, ?, 'CAM_FLOOR_01', 'VIS_old01', 'ZONE_ENTER', ?, 'SKINCARE', 0, 0, 0.85)
            """, (str(uuid.uuid4()), store_id, old_ts))
            await db.commit()

        # No recent events for this zone
        resp = await client.get(f"/stores/{store_id}/anomalies")
        data = resp.json()
        dead = [a for a in data["active_anomalies"] if a["anomaly_type"] == "DEAD_ZONE"]
        assert len(dead) >= 1
        assert dead[0]["severity"] == "INFO"
        assert dead[0]["zone_id"] == "SKINCARE"

    @pytest.mark.asyncio
    async def test_no_dead_zone_with_recent_visits(self, client):
        store_id = "STORE_ACTIVE_ZONES"
        events = [make_event(
            event_type="ZONE_ENTER", store_id=store_id, zone_id="SKINCARE",
        )]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/anomalies")
        data = resp.json()
        dead = [a for a in data["active_anomalies"] if a["anomaly_type"] == "DEAD_ZONE"]
        # Should not flag SKINCARE as dead since we just sent a visit
        skincare_dead = [a for a in dead if a.get("zone_id") == "SKINCARE"]
        assert len(skincare_dead) == 0
