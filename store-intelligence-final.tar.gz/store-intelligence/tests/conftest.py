"""
conftest.py — Shared pytest fixtures for Store Intelligence test suite.

Key design decisions:
  - Each test gets an isolated SQLite DB (tmp_path scoped) — no test pollution
  - DB path set via environment variable before app imports — critical for aiosqlite
  - AsyncClient uses ASGITransport — no real HTTP, but full middleware stack runs
  - Fixtures are function-scoped by default so each test starts clean
"""

import pytest
import pytest_asyncio
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from httpx import AsyncClient, ASGITransport


# ── Core async client fixture ──────────────────────────────────────────────────

@pytest_asyncio.fixture
async def client(tmp_path, monkeypatch):
    """
    Async HTTP client with full app stack and isolated DB.
    Use this in any test that hits API endpoints.
    """
    db_file = str(tmp_path / f"test_{uuid.uuid4().hex[:6]}.db")
    monkeypatch.setenv("DATABASE_URL", db_file)

    import importlib
    import app.db.database as db_mod
    db_mod.DB_PATH = db_file
    importlib.reload(db_mod)

    from app.main import app
    from app.db.database import init_db
    await init_db(db_file)

    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://test") as ac:
        yield ac


# ── DB-only fixture (no HTTP) ──────────────────────────────────────────────────

@pytest_asyncio.fixture
async def db(tmp_path, monkeypatch):
    """
    Raw DB connection for tests that test services directly without HTTP.
    """
    db_file = str(tmp_path / f"test_{uuid.uuid4().hex[:6]}.db")
    monkeypatch.setenv("DATABASE_URL", db_file)

    import app.db.database as db_mod
    db_mod.DB_PATH = db_file

    from app.db.database import init_db, get_db
    await init_db(db_file)

    async with get_db() as conn:
        yield conn


# ── Event factory helpers ──────────────────────────────────────────────────────

def make_event(
    event_type="ENTRY",
    visitor_id=None,
    store_id="STORE_BLR_002",
    zone_id=None,
    is_staff=False,
    confidence=0.85,
    dwell_ms=0,
    timestamp=None,
    camera_id="CAM_ENTRY_01",
    metadata=None,
):
    """
    Factory for valid StoreEvent dicts. Suitable for both direct DB inserts
    and POST /events/ingest payloads.
    """
    return {
        "event_id": str(uuid.uuid4()),
        "store_id": store_id,
        "camera_id": camera_id,
        "visitor_id": visitor_id or f"VIS_{uuid.uuid4().hex[:6]}",
        "event_type": event_type,
        "timestamp": timestamp or datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "zone_id": zone_id,
        "dwell_ms": dwell_ms,
        "is_staff": is_staff,
        "confidence": confidence,
        "metadata": metadata or {"queue_depth": None, "sku_zone": zone_id, "session_seq": 1},
    }


def make_visitor_session(
    store_id: str,
    visitor_id: str = None,
    entered_at: datetime = None,
    zones: list = None,
    purchased: bool = False,
    is_staff: bool = False,
) -> list:
    """
    Build a realistic sequence of events for a full visitor session.
    Returns a list of event dicts ready for POST /events/ingest.
    """
    vid = visitor_id or f"VIS_{uuid.uuid4().hex[:6]}"
    base_ts = entered_at or datetime.now(timezone.utc)
    events = []

    # Entry
    events.append(make_event(
        event_type="ENTRY", visitor_id=vid, store_id=store_id,
        timestamp=base_ts.strftime("%Y-%m-%dT%H:%M:%SZ"),
        is_staff=is_staff,
    ))

    # Zone visits
    for i, zone in enumerate(zones or ["SKINCARE"]):
        t = base_ts + timedelta(minutes=i * 3 + 1)
        events.append(make_event(
            event_type="ZONE_ENTER", visitor_id=vid, store_id=store_id,
            zone_id=zone, timestamp=t.strftime("%Y-%m-%dT%H:%M:%SZ"),
            is_staff=is_staff,
        ))
        events.append(make_event(
            event_type="ZONE_EXIT", visitor_id=vid, store_id=store_id,
            zone_id=zone, dwell_ms=90000,  # 90s dwell
            timestamp=(t + timedelta(seconds=90)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            is_staff=is_staff,
        ))

    # Billing
    billing_t = base_ts + timedelta(minutes=len(zones or []) * 3 + 5)
    events.append(make_event(
        event_type="ZONE_ENTER", visitor_id=vid, store_id=store_id,
        zone_id="BILLING", timestamp=billing_t.strftime("%Y-%m-%dT%H:%M:%SZ"),
        is_staff=is_staff,
    ))

    # Exit
    exit_t = billing_t + timedelta(minutes=5)
    events.append(make_event(
        event_type="EXIT", visitor_id=vid, store_id=store_id,
        timestamp=exit_t.strftime("%Y-%m-%dT%H:%M:%SZ"),
        is_staff=is_staff,
    ))

    return events


# ── POS transaction helper ─────────────────────────────────────────────────────

def make_pos_transaction(
    store_id: str = "STORE_BLR_002",
    timestamp: datetime = None,
    basket_value: float = 999.0,
) -> dict:
    ts = timestamp or datetime.now(timezone.utc)
    return {
        "transaction_id": f"TXN_{uuid.uuid4().hex[:8].upper()}",
        "store_id": store_id,
        "timestamp": ts.strftime("%Y-%m-%dT%H:%M:%SZ"),
        "basket_value_inr": basket_value,
    }
