# PROMPT:
# "Write pytest tests for a store heatmap API endpoint (GET /stores/{id}/heatmap)
# and a POS transaction ingest endpoint (POST /pos/ingest).
# Heatmap tests: empty store returns empty zones list, normalised_score in 0-100,
# highest-traffic zone scores 100, data_confidence=LOW under 20 sessions.
# POS tests: idempotency by transaction_id, invalid CSV rows return errors not 5xx,
# conversion rate increases after POS correlation with billing zone events.
# Include full visitor session simulation using conftest make_visitor_session helper."
#
# CHANGES MADE:
# - AI generated heatmap score assertion as >=99.9 — changed to ==100.0 exactly
#   (our normalisation formula guarantees max=100, not approximately 100)
# - AI's POS idempotency test used the same fixture as metrics — gave it its own
#   isolated store_id to avoid state leakage between tests
# - Added conversion_rate_increases_with_pos_data test — AI omitted end-to-end
#   correlation test which is the most important business logic to verify

import pytest
import pytest_asyncio
import uuid
from datetime import datetime, timezone, timedelta

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from tests.conftest import make_event, make_visitor_session, make_pos_transaction

STORE_ID = "STORE_BLR_002"


# ── Heatmap endpoint ───────────────────────────────────────────────────────────

class TestHeatmap:

    @pytest.mark.asyncio
    async def test_heatmap_returns_200(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/heatmap")
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_heatmap_empty_store_returns_empty_zones(self, client):
        resp = await client.get("/stores/STORE_EMPTY_HEATMAP/heatmap")
        assert resp.status_code == 200
        data = resp.json()
        assert data["zones"] == []
        assert data["data_confidence"] == "LOW"

    @pytest.mark.asyncio
    async def test_heatmap_normalised_score_range(self, client):
        """All normalised_score values must be in [0, 100]."""
        store_id = "STORE_HEATMAP_RANGE"
        events = []
        for zone in ["SKINCARE", "HAIRCARE", "BILLING"]:
            for _ in range(3):
                vid = f"VIS_{uuid.uuid4().hex[:6]}"
                events.append(make_event(event_type="ZONE_ENTER", store_id=store_id, zone_id=zone, visitor_id=vid))
                events.append(make_event(event_type="ZONE_EXIT", store_id=store_id, zone_id=zone,
                                          visitor_id=vid, dwell_ms=60000))
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/heatmap")
        data = resp.json()
        for zone in data["zones"]:
            assert 0.0 <= zone["normalised_score"] <= 100.0, \
                f"Score {zone['normalised_score']} out of range for zone {zone['zone_id']}"

    @pytest.mark.asyncio
    async def test_heatmap_top_zone_scores_100(self, client):
        """The highest traffic zone must have normalised_score = 100."""
        store_id = "STORE_HEATMAP_TOP"
        # Skincare: 10 visits. Haircare: 2 visits
        events = []
        for _ in range(10):
            vid = f"VIS_{uuid.uuid4().hex[:6]}"
            events.append(make_event(event_type="ZONE_ENTER", store_id=store_id,
                                      zone_id="SKINCARE", visitor_id=vid, dwell_ms=90000))
            events.append(make_event(event_type="ZONE_EXIT", store_id=store_id,
                                      zone_id="SKINCARE", visitor_id=vid, dwell_ms=90000))
        for _ in range(2):
            vid = f"VIS_{uuid.uuid4().hex[:6]}"
            events.append(make_event(event_type="ZONE_ENTER", store_id=store_id,
                                      zone_id="HAIRCARE", visitor_id=vid))
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/heatmap")
        data = resp.json()
        scores = {z["zone_id"]: z["normalised_score"] for z in data["zones"]}
        assert scores.get("SKINCARE") == 100.0, \
            f"Expected SKINCARE=100, got {scores}"

    @pytest.mark.asyncio
    async def test_heatmap_data_confidence_low_under_20_sessions(self, client):
        store_id = "STORE_HEATMAP_LOWCONF"
        # Only 5 visitors — below 20 threshold
        for _ in range(5):
            vid = f"VIS_{uuid.uuid4().hex[:6]}"
            events = [make_event(event_type="ENTRY", visitor_id=vid, store_id=store_id)]
            await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/heatmap")
        data = resp.json()
        assert data["data_confidence"] == "LOW"

    @pytest.mark.asyncio
    async def test_heatmap_data_confidence_high_over_20_sessions(self, client):
        store_id = "STORE_HEATMAP_HIGHCONF"
        events = []
        for _ in range(25):
            vid = f"VIS_{uuid.uuid4().hex[:6]}"
            events.append(make_event(event_type="ENTRY", visitor_id=vid, store_id=store_id))
            events.append(make_event(event_type="ZONE_ENTER", visitor_id=vid, store_id=store_id,
                                      zone_id="SKINCARE"))
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/heatmap")
        data = resp.json()
        assert data["data_confidence"] == "HIGH"

    @pytest.mark.asyncio
    async def test_heatmap_response_schema(self, client):
        resp = await client.get(f"/stores/{STORE_ID}/heatmap")
        data = resp.json()
        required = ["store_id", "window_start", "window_end", "zones", "data_confidence"]
        for field in required:
            assert field in data, f"Missing: {field}"
        assert isinstance(data["zones"], list)


# ── POS ingest endpoint ────────────────────────────────────────────────────────

class TestPosIngest:

    @pytest.mark.asyncio
    async def test_pos_ingest_returns_200(self, client):
        txn = make_pos_transaction()
        resp = await client.post("/pos/ingest", json={"transactions": [txn]})
        assert resp.status_code == 200

    @pytest.mark.asyncio
    async def test_pos_ingest_response_schema(self, client):
        txn = make_pos_transaction()
        resp = await client.post("/pos/ingest", json={"transactions": [txn]})
        data = resp.json()
        assert "ingested" in data
        assert "duplicates" in data
        assert "status" in data

    @pytest.mark.asyncio
    async def test_pos_ingest_idempotency(self, client):
        """Same transaction_id posted twice → 1 ingested, 1 duplicate."""
        txn = make_pos_transaction(store_id="STORE_POS_IDEM")
        resp1 = await client.post("/pos/ingest", json={"transactions": [txn]})
        resp2 = await client.post("/pos/ingest", json={"transactions": [txn]})
        assert resp1.json()["ingested"] == 1
        assert resp2.json()["ingested"] == 0
        assert resp2.json()["duplicates"] == 1

    @pytest.mark.asyncio
    async def test_pos_ingest_batch(self, client):
        txns = [make_pos_transaction() for _ in range(50)]
        resp = await client.post("/pos/ingest", json={"transactions": txns})
        assert resp.json()["ingested"] == 50


# ── End-to-end: POS correlation → conversion rate ─────────────────────────────

class TestPosConversionCorrelation:

    @pytest.mark.asyncio
    async def test_conversion_rate_zero_without_pos(self, client):
        """Visitors in billing but no POS transactions → conversion = 0.0"""
        store_id = "STORE_CONV_NPOS"
        vid = f"VIS_{uuid.uuid4().hex[:6]}"
        events = [
            make_event(event_type="ENTRY", visitor_id=vid, store_id=store_id),
            make_event(event_type="ZONE_ENTER", visitor_id=vid, store_id=store_id, zone_id="BILLING"),
        ]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get(f"/stores/{store_id}/metrics")
        assert resp.json()["conversion_rate"] == 0.0

    @pytest.mark.asyncio
    async def test_conversion_rate_increases_with_pos_data(self, client):
        """
        Full end-to-end: visitor enters, visits billing zone, POS transaction
        within 5 minutes → conversion_rate > 0.
        """
        store_id = "STORE_CONV_E2E"
        now = datetime.now(timezone.utc)
        billing_time = now - timedelta(minutes=3)
        purchase_time = now - timedelta(minutes=1)  # 2 min after billing visit

        vid = f"VIS_{uuid.uuid4().hex[:6]}"
        events = [
            make_event(event_type="ENTRY", visitor_id=vid, store_id=store_id,
                       timestamp=(now - timedelta(minutes=10)).strftime("%Y-%m-%dT%H:%M:%SZ")),
            make_event(event_type="ZONE_ENTER", visitor_id=vid, store_id=store_id,
                       zone_id="BILLING",
                       timestamp=billing_time.strftime("%Y-%m-%dT%H:%M:%SZ")),
        ]
        await client.post("/events/ingest", json={"events": events})

        # POS transaction 2 minutes after billing visit
        txn = make_pos_transaction(store_id=store_id, timestamp=purchase_time)
        await client.post("/pos/ingest", json={"transactions": [txn]})

        resp = await client.get(f"/stores/{store_id}/metrics")
        data = resp.json()
        assert data["conversion_rate"] > 0.0, \
            f"Expected conversion_rate > 0 after POS correlation, got {data['conversion_rate']}"

    @pytest.mark.asyncio
    async def test_conversion_rate_not_inflated_by_non_billing_visitors(self, client):
        """Visitors who never entered billing should not be counted as converted."""
        store_id = "STORE_CONV_NOBILL"
        now = datetime.now(timezone.utc)

        # 5 visitors — none entered billing
        for _ in range(5):
            vid = f"VIS_{uuid.uuid4().hex[:6]}"
            events = [
                make_event(event_type="ENTRY", visitor_id=vid, store_id=store_id),
                make_event(event_type="ZONE_ENTER", visitor_id=vid, store_id=store_id,
                           zone_id="SKINCARE"),
            ]
            await client.post("/events/ingest", json={"events": events})

        # POS transaction exists
        txn = make_pos_transaction(store_id=store_id, timestamp=now)
        await client.post("/pos/ingest", json={"transactions": [txn]})

        resp = await client.get(f"/stores/{store_id}/metrics")
        data = resp.json()
        # Conversion should be 0 — nobody was in billing
        assert data["conversion_rate"] == 0.0

    @pytest.mark.asyncio
    async def test_funnel_purchase_stage_populated_with_pos(self, client):
        """Funnel Purchase stage count > 0 after POS correlation."""
        store_id = "STORE_FUNNEL_POS"
        now = datetime.now(timezone.utc)
        vid = f"VIS_{uuid.uuid4().hex[:6]}"

        events = [
            make_event(event_type="ENTRY", visitor_id=vid, store_id=store_id,
                       timestamp=(now - timedelta(minutes=8)).strftime("%Y-%m-%dT%H:%M:%SZ")),
            make_event(event_type="ZONE_ENTER", visitor_id=vid, store_id=store_id,
                       zone_id="BILLING",
                       timestamp=(now - timedelta(minutes=4)).strftime("%Y-%m-%dT%H:%M:%SZ")),
        ]
        await client.post("/events/ingest", json={"events": events})
        txn = make_pos_transaction(store_id=store_id, timestamp=now - timedelta(minutes=2))
        await client.post("/pos/ingest", json={"transactions": [txn]})

        resp = await client.get(f"/stores/{store_id}/funnel")
        stages = {s["stage"]: s["count"] for s in resp.json()["stages"]}
        assert stages.get("Purchase", 0) > 0, \
            f"Expected Purchase > 0, got funnel stages: {stages}"


# ── Stores listing endpoint ────────────────────────────────────────────────────

class TestStoresListing:

    @pytest.mark.asyncio
    async def test_stores_endpoint_returns_list(self, client):
        resp = await client.get("/stores")
        assert resp.status_code == 200
        assert isinstance(resp.json(), list)

    @pytest.mark.asyncio
    async def test_stores_lists_after_events_ingested(self, client):
        store_id = "STORE_LISTED_001"
        events = [make_event(store_id=store_id)]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get("/stores")
        store_ids = [s["store_id"] for s in resp.json()]
        assert store_id in store_ids

    @pytest.mark.asyncio
    async def test_store_info_schema(self, client):
        store_id = "STORE_SCHEMA_CHECK"
        events = [make_event(store_id=store_id)]
        await client.post("/events/ingest", json={"events": events})

        resp = await client.get("/stores")
        stores = resp.json()
        target = next((s for s in stores if s["store_id"] == store_id), None)
        assert target is not None
        assert "store_id" in target
        assert "last_event_at" in target
        assert "total_events" in target
        assert target["total_events"] >= 1
