"""
dashboard/live_dashboard.py — Live terminal dashboard for Store Intelligence.

Shows real-time metrics updating as events are ingested:
  - Unique visitors today
  - Conversion rate (live %)
  - Current billing queue depth
  - Abandonment rate
  - Active anomalies (colour-coded by severity)
  - Per-zone dwell heatmap (ASCII bar chart)

Usage:
    python3 dashboard/live_dashboard.py
    python3 dashboard/live_dashboard.py --api http://localhost:8000 --store STORE_BLR_002 --refresh 5
"""

import time
import sys
import os
import argparse
import requests
from datetime import datetime, timezone
from typing import Optional

try:
    from rich.console import Console
    from rich.table import Table
    from rich.panel import Panel
    from rich.layout import Layout
    from rich.live import Live
    from rich.text import Text
    from rich.columns import Columns
    from rich import box
    from rich.progress_bar import ProgressBar
except ImportError:
    print("rich not installed. Run: pip install rich")
    sys.exit(1)

console = Console()

DEFAULT_API = os.getenv("API_URL", "http://localhost:8000")
DEFAULT_STORE = os.getenv("STORE_ID", "STORE_BLR_002")
DEFAULT_REFRESH = 5  # seconds


def fetch_json(url: str, timeout: int = 5) -> Optional[dict]:
    try:
        resp = requests.get(url, timeout=timeout)
        resp.raise_for_status()
        return resp.json()
    except Exception as e:
        return None


def severity_color(severity: str) -> str:
    return {"INFO": "cyan", "WARN": "yellow", "CRITICAL": "red"}.get(severity, "white")


def build_dashboard(api_url: str, store_id: str) -> Layout:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    # Fetch all data
    metrics = fetch_json(f"{api_url}/stores/{store_id}/metrics")
    funnel = fetch_json(f"{api_url}/stores/{store_id}/funnel")
    anomalies = fetch_json(f"{api_url}/stores/{store_id}/anomalies")
    health = fetch_json(f"{api_url}/health")

    layout = Layout()
    layout.split_column(
        Layout(name="header", size=3),
        Layout(name="body"),
        Layout(name="footer", size=3),
    )
    layout["body"].split_row(
        Layout(name="left"),
        Layout(name="right"),
    )
    layout["left"].split_column(
        Layout(name="metrics", ratio=2),
        Layout(name="funnel", ratio=3),
    )
    layout["right"].split_column(
        Layout(name="heatmap", ratio=2),
        Layout(name="anomalies", ratio=3),
    )

    # ── Header ─────────────────────────────────────────────────────────────────
    db_status = health.get("database", "?") if health else "unreachable"
    api_status = "🟢 online" if health else "🔴 offline"
    header_text = Text()
    header_text.append("  🏪 Store Intelligence — Live Dashboard  ", style="bold white on blue")
    header_text.append(f"  {store_id}  ", style="bold cyan")
    header_text.append(f"  API: {api_status}  DB: {db_status}  ", style="dim")
    header_text.append(f"  Refreshed: {now}  ", style="dim")
    layout["header"].update(Panel(header_text, style="blue"))

    # ── Metrics panel ──────────────────────────────────────────────────────────
    if metrics:
        uv = metrics.get("unique_visitors", 0)
        cr = metrics.get("conversion_rate", 0.0)
        qd = metrics.get("queue_depth", 0)
        ar = metrics.get("abandonment_rate", 0.0)
        txn = metrics.get("total_transactions", 0)
        conf = metrics.get("data_confidence", "?")

        metrics_table = Table(box=box.SIMPLE, show_header=False, padding=(0, 1))
        metrics_table.add_column("Metric", style="dim")
        metrics_table.add_column("Value", style="bold")

        cr_color = "green" if cr >= 0.3 else ("yellow" if cr >= 0.1 else "red")
        qd_color = "red" if qd >= 10 else ("yellow" if qd >= 5 else "green")
        ar_color = "red" if ar >= 0.4 else ("yellow" if ar >= 0.2 else "green")

        metrics_table.add_row("Unique Visitors Today", f"[bold cyan]{uv}[/]")
        metrics_table.add_row("Conversion Rate", f"[{cr_color}]{cr:.1%}[/]")
        metrics_table.add_row("Queue Depth (now)", f"[{qd_color}]{qd} customers[/]")
        metrics_table.add_row("Abandonment Rate", f"[{ar_color}]{ar:.1%}[/]")
        metrics_table.add_row("Transactions Today", f"[bold]{txn}[/]")
        metrics_table.add_row("Data Confidence", f"[{'green' if conf == 'HIGH' else 'yellow'}]{conf}[/]")

        layout["metrics"].update(Panel(metrics_table, title="📊 Live Metrics", border_style="blue"))
    else:
        layout["metrics"].update(Panel("[red]Metrics unavailable[/]", title="📊 Live Metrics"))

    # ── Funnel panel ───────────────────────────────────────────────────────────
    if funnel and funnel.get("stages"):
        funnel_table = Table(box=box.SIMPLE, padding=(0, 1))
        funnel_table.add_column("Stage", style="bold")
        funnel_table.add_column("Count", justify="right")
        funnel_table.add_column("Drop-off", justify="right")
        funnel_table.add_column("Bar", no_wrap=True)

        max_count = max((s["count"] for s in funnel["stages"]), default=1) or 1
        stage_icons = {"Entry": "🚪", "Zone Visit": "🛍️", "Billing Queue": "💳", "Purchase": "✅"}

        for stage in funnel["stages"]:
            name = stage["stage"]
            count = stage["count"]
            drop = stage["drop_off_pct"]
            bar_len = int((count / max_count) * 20)
            bar = "█" * bar_len + "░" * (20 - bar_len)
            drop_color = "red" if drop > 50 else ("yellow" if drop > 20 else "green")
            funnel_table.add_row(
                f"{stage_icons.get(name, '•')} {name}",
                str(count),
                f"[{drop_color}]-{drop:.1f}%[/]",
                f"[cyan]{bar}[/]",
            )

        layout["funnel"].update(Panel(funnel_table, title="🔽 Conversion Funnel", border_style="cyan"))
    else:
        layout["funnel"].update(Panel("[dim]No funnel data yet[/]", title="🔽 Conversion Funnel"))

    # ── Heatmap panel ──────────────────────────────────────────────────────────
    heatmap_data = fetch_json(f"{api_url}/stores/{store_id}/heatmap")
    if heatmap_data and heatmap_data.get("zones"):
        heat_table = Table(box=box.SIMPLE, padding=(0, 1))
        heat_table.add_column("Zone", style="bold")
        heat_table.add_column("Visits", justify="right")
        heat_table.add_column("Avg Dwell", justify="right")
        heat_table.add_column("Heat", no_wrap=True)

        zones = sorted(heatmap_data["zones"], key=lambda z: z["normalised_score"], reverse=True)[:8]
        for z in zones:
            score = z["normalised_score"]
            bar_len = int(score / 100 * 15)
            if score >= 70:
                color = "red"
            elif score >= 40:
                color = "yellow"
            else:
                color = "green"
            dwell_sec = z["avg_dwell_ms"] / 1000
            heat_table.add_row(
                z["zone_id"][:15],
                str(z["visit_frequency"]),
                f"{dwell_sec:.0f}s",
                f"[{color}]{'█' * bar_len}{'░' * (15 - bar_len)}[/] {score:.0f}",
            )

        layout["heatmap"].update(Panel(heat_table, title="🔥 Zone Heatmap", border_style="yellow"))
    else:
        layout["heatmap"].update(Panel("[dim]No heatmap data yet[/]", title="🔥 Zone Heatmap"))

    # ── Anomalies panel ────────────────────────────────────────────────────────
    if anomalies:
        active = anomalies.get("active_anomalies", [])
        if active:
            anom_table = Table(box=box.SIMPLE, padding=(0, 1))
            anom_table.add_column("!", style="bold", width=4)
            anom_table.add_column("Type", style="bold")
            anom_table.add_column("Description", no_wrap=False)

            severity_icon = {"INFO": "ℹ️", "WARN": "⚠️", "CRITICAL": "🚨"}
            for a in active[:6]:  # show max 6
                sev = a["severity"]
                color = severity_color(sev)
                anom_table.add_row(
                    f"[{color}]{severity_icon.get(sev, '?')}[/]",
                    f"[{color}]{a['anomaly_type']}[/]",
                    a["description"][:60],
                )
            layout["anomalies"].update(Panel(
                anom_table,
                title=f"🚨 Anomalies ({len(active)} active)",
                border_style="red" if any(a["severity"] == "CRITICAL" for a in active) else "yellow",
            ))
        else:
            layout["anomalies"].update(Panel(
                "[green]✅ No active anomalies[/]",
                title="🚨 Anomalies",
                border_style="green",
            ))
    else:
        layout["anomalies"].update(Panel("[dim]Anomaly service unavailable[/]", title="🚨 Anomalies"))

    # ── Footer ─────────────────────────────────────────────────────────────────
    layout["footer"].update(Panel(
        f"[dim]Refresh every {DEFAULT_REFRESH}s | Ctrl+C to exit | API: {api_url}[/]",
        style="dim",
    ))

    return layout


def main():
    parser = argparse.ArgumentParser(description="Store Intelligence Live Dashboard")
    parser.add_argument("--api", default=DEFAULT_API, help="API base URL")
    parser.add_argument("--store", default=DEFAULT_STORE, help="Store ID")
    parser.add_argument("--refresh", type=int, default=DEFAULT_REFRESH, help="Refresh interval (seconds)")
    args = parser.parse_args()

    console.clear()
    console.print(f"[bold]Connecting to {args.api}...[/]")

    with Live(console=console, refresh_per_second=1, screen=True) as live:
        while True:
            try:
                layout = build_dashboard(args.api, args.store)
                live.update(layout)
                time.sleep(args.refresh)
            except KeyboardInterrupt:
                console.print("\n[yellow]Dashboard stopped.[/]")
                break
            except Exception as e:
                console.print(f"[red]Dashboard error: {e}[/]")
                time.sleep(args.refresh)


if __name__ == "__main__":
    main()
