"""
detect.py — Main detection + tracking script for Purplle Store Intelligence
Processes CCTV clips using YOLOv8 + ByteTrack, emits structured events.

Pipeline:
  Video clip → YOLOv8 person detection → ByteTrack multi-object tracking
  → Zone classification (homography + polygon intersection)
  → Staff detection (torso color histogram)
  → Re-ID (OSNet embeddings for cross-camera dedup + re-entry detection)
  → Event emission (structured JSON events per schema)
"""

import cv2
import json
import argparse
import logging
import sys
from pathlib import Path
from datetime import datetime, timezone, timedelta
from typing import Optional

import numpy as np

# Local modules
from tracker import MultiCameraTracker
from emit import EventEmitter
from staff_detector import StaffDetector
from zone_classifier import ZoneClassifier

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)],
)
log = logging.getLogger("detect")


def load_store_layout(layout_path: Path) -> dict:
    with open(layout_path) as f:
        return json.load(f)


def clip_start_time(clip_path: Path, store_layout: dict, store_id: str) -> datetime:
    """
    Derive the wall-clock start time of a clip.
    Falls back to store open time if clip filename has no embedded timestamp.
    Filename convention: STORE_BLR_002__CAM_ENTRY_01__2026-03-03T09-00-00Z.mp4
    """
    stem = clip_path.stem
    parts = stem.split("__")
    if len(parts) >= 3:
        ts_str = parts[2].replace("-", ":").replace("T", "T")
        # Fix back: 2026:03:03T09:00:00Z → parse manually
        try:
            ts_str = parts[2]  # e.g. 2026-03-03T09-00-00Z
            ts_str = ts_str[:10] + "T" + ts_str[11:].replace("-", ":").rstrip("Z") + "Z"
            return datetime.fromisoformat(ts_str.replace("Z", "+00:00"))
        except Exception:
            pass

    # Fallback: use store open time from layout
    for store in store_layout.get("stores", []):
        if store.get("store_id") == store_id:
            open_time = store.get("open_hours", {}).get("open", "09:00")
            today = datetime.now(timezone.utc).date()
            h, m = map(int, open_time.split(":"))
            return datetime(today.year, today.month, today.day, h, m, 0, tzinfo=timezone.utc)

    return datetime.now(timezone.utc)


def get_store_id_from_path(clip_path: Path) -> str:
    """Extract store_id from clip filename or parent directory name."""
    stem = clip_path.stem
    parts = stem.split("__")
    if parts:
        return parts[0]
    return clip_path.parent.name


def get_camera_id_from_path(clip_path: Path) -> str:
    """Extract camera_id from clip filename."""
    stem = clip_path.stem
    parts = stem.split("__")
    if len(parts) >= 2:
        return parts[1]
    return clip_path.stem


def process_clip(
    clip_path: Path,
    store_layout: dict,
    output_path: Path,
    camera_type: str = "auto",
    api_url: Optional[str] = None,
    batch_size: int = 100,
):
    """
    Process a single CCTV clip end-to-end.

    Args:
        clip_path:    Path to the .mp4 clip
        store_layout: Parsed store_layout.json
        output_path:  Where to write .jsonl events
        camera_type:  'entry', 'floor', 'billing', or 'auto' (inferred from filename)
        api_url:      If set, POST events to API in real time
        batch_size:   Events per API batch
    """
    store_id = get_store_id_from_path(clip_path)
    camera_id = get_camera_id_from_path(clip_path)

    if camera_type == "auto":
        cam_lower = camera_id.lower()
        if "entry" in cam_lower or "exit" in cam_lower:
            camera_type = "entry"
        elif "billing" in cam_lower or "checkout" in cam_lower:
            camera_type = "billing"
        else:
            camera_type = "floor"

    log.info(f"Processing clip: {clip_path.name}  store={store_id}  camera={camera_id}  type={camera_type}")

    cap = cv2.VideoCapture(str(clip_path))
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open video: {clip_path}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 15.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    clip_start = clip_start_time(clip_path, store_layout, store_id)

    log.info(f"  FPS={fps:.1f}  frames={total_frames}  start={clip_start.isoformat()}")

    # Initialise components
    try:
        from ultralytics import YOLO
        model = YOLO("yolov8s.pt")  # small model — good balance of speed/accuracy
        log.info("  YOLOv8s loaded")
    except ImportError:
        log.error("ultralytics not installed. Run: pip install ultralytics")
        raise

    zone_classifier = ZoneClassifier(store_layout, store_id, camera_id)
    staff_detector = StaffDetector()
    tracker = MultiCameraTracker(store_id=store_id, reid_threshold=0.65)
    emitter = EventEmitter(
        store_id=store_id,
        camera_id=camera_id,
        output_path=output_path,
        api_url=api_url,
        batch_size=batch_size,
    )

    frame_idx = 0
    event_count = 0
    process_every_n = max(1, int(fps / 5))  # process 5 frames/sec — sufficient for retail

    log.info(f"  Processing every {process_every_n} frames (~5fps effective)")

    while True:
        ret, frame = cap.read()
        if not ret:
            break

        frame_idx += 1
        if frame_idx % process_every_n != 0:
            continue

        # Wall-clock timestamp for this frame
        elapsed_sec = frame_idx / fps
        frame_ts = clip_start + timedelta(seconds=elapsed_sec)

        # ── Detection ──────────────────────────────────────────────────────────
        results = model(
            frame,
            classes=[0],        # class 0 = person
            conf=0.30,          # low threshold — we keep low-conf events, just flag them
            verbose=False,
        )

        detections = []
        if results and len(results) > 0:
            for box in results[0].boxes:
                x1, y1, x2, y2 = box.xyxy[0].cpu().numpy()
                conf = float(box.conf[0].cpu().numpy())
                detections.append({
                    "bbox": [float(x1), float(y1), float(x2), float(y2)],
                    "confidence": conf,
                    "frame": frame,
                })

        # ── Staff classification ───────────────────────────────────────────────
        for det in detections:
            det["is_staff"] = staff_detector.classify(frame, det["bbox"])

        # ── Tracking + Re-ID ──────────────────────────────────────────────────
        track_updates = tracker.update(
            detections=detections,
            frame=frame,
            frame_ts=frame_ts,
            camera_type=camera_type,
        )

        # ── Zone classification ────────────────────────────────────────────────
        for track in track_updates:
            bbox = track.get("bbox", [0, 0, 0, 0])
            cx = (bbox[0] + bbox[2]) / 2
            cy = (bbox[1] + bbox[3]) / 2
            track["zone_id"] = zone_classifier.classify_point(cx, cy)

        # ── Event emission ─────────────────────────────────────────────────────
        new_events = emitter.process_track_updates(track_updates, frame_ts)
        event_count += len(new_events)

        if frame_idx % (process_every_n * 100) == 0:
            pct = 100 * frame_idx / max(total_frames, 1)
            log.info(f"  Progress: {pct:.1f}%  events_emitted={event_count}")

    # Flush remaining events
    emitter.flush(frame_ts)
    cap.release()

    log.info(f"  Done. Total events emitted: {event_count}")
    return event_count


def main():
    parser = argparse.ArgumentParser(description="Store Intelligence Detection Pipeline")
    parser.add_argument("clips_dir", type=Path, help="Directory containing .mp4 clips")
    parser.add_argument("layout", type=Path, help="Path to store_layout.json")
    parser.add_argument("output", type=Path, help="Output .jsonl file path")
    parser.add_argument("--api-url", default=None, help="API base URL for live ingest (e.g. http://localhost:8000)")
    parser.add_argument("--batch-size", type=int, default=100, help="Events per API batch")
    parser.add_argument("--clip", default=None, help="Process a single clip file instead of directory")
    args = parser.parse_args()

    store_layout = load_store_layout(args.layout)
    args.output.parent.mkdir(parents=True, exist_ok=True)

    if args.clip:
        clips = [Path(args.clip)]
    else:
        clips = sorted(Path(args.clips_dir).glob("**/*.mp4"))
        if not clips:
            clips = sorted(Path(args.clips_dir).glob("**/*.avi"))

    if not clips:
        log.error(f"No video clips found in {args.clips_dir}")
        sys.exit(1)

    log.info(f"Found {len(clips)} clip(s) to process")

    total_events = 0
    for clip_path in clips:
        try:
            count = process_clip(
                clip_path=clip_path,
                store_layout=store_layout,
                output_path=args.output,
                api_url=args.api_url,
                batch_size=args.batch_size,
            )
            total_events += count
        except Exception as e:
            log.error(f"Failed to process {clip_path.name}: {e}", exc_info=True)

    log.info(f"Pipeline complete. Total events across all clips: {total_events}")
    log.info(f"Events written to: {args.output}")


if __name__ == "__main__":
    main()
