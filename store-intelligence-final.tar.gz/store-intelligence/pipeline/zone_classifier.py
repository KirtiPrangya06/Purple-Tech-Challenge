"""
zone_classifier.py — Map pixel coordinates to named store zones.

Strategy:
  store_layout.json defines zones as polygons in floor-plan coordinates.
  Each camera has a homography matrix mapping pixel coords → floor coords.
  We classify a detection by:
    1. Apply camera homography to get floor coordinate
    2. Check which zone polygon contains that floor coordinate
    3. Return the zone_id (or None for "aisle" / unmapped areas)

  If no homography is configured (common in challenge datasets), we fall back
  to relative bbox position within the frame — dividing the frame into regions
  based on camera type (entry, floor, billing).

Homography format in store_layout.json (optional):
  {
    "cameras": {
      "CAM_ENTRY_01": {
        "homography": [[...3x3 matrix...]]
      }
    }
  }
"""

import logging
import json
import numpy as np
import cv2
from typing import Optional

log = logging.getLogger("zone_classifier")


def point_in_polygon(px: float, py: float, polygon: list) -> bool:
    """Ray-casting algorithm for point-in-polygon test."""
    n = len(polygon)
    inside = False
    j = n - 1
    for i in range(n):
        xi, yi = polygon[i]
        xj, yj = polygon[j]
        if ((yi > py) != (yj > py)) and (px < (xj - xi) * (py - yi) / (yj - yi + 1e-9) + xi):
            inside = not inside
        j = i
    return inside


class ZoneClassifier:
    """
    Classifies (cx, cy) pixel coordinates into named store zones.
    """

    def __init__(self, store_layout: dict, store_id: str, camera_id: str):
        self.store_id = store_id
        self.camera_id = camera_id
        self._zones = []           # list of {zone_id, polygon (floor coords), sku_zone}
        self._homography = None    # 3x3 np.ndarray or None
        self._fallback_regions = []

        self._load_from_layout(store_layout)

    def _load_from_layout(self, layout: dict):
        """Parse store_layout.json for zones and optional homography."""
        # Find this store
        store_data = None
        for store in layout.get("stores", []):
            if store.get("store_id") == self.store_id:
                store_data = store
                break

        if not store_data:
            log.warning(f"store_id {self.store_id} not found in layout, using fallback zones")
            self._setup_fallback()
            return

        # Load zone polygons
        for zone in store_data.get("zones", []):
            zone_id = zone.get("zone_id") or zone.get("name")
            polygon = zone.get("polygon", [])  # list of [x, y] floor coords
            sku_zone = zone.get("sku_zone") or zone_id
            if zone_id and polygon:
                self._zones.append({
                    "zone_id": zone_id,
                    "polygon": polygon,
                    "sku_zone": sku_zone,
                })

        # Load homography for this camera
        cameras = store_data.get("cameras", {})
        cam_data = cameras.get(self.camera_id, {})
        h_matrix = cam_data.get("homography")
        if h_matrix:
            self._homography = np.array(h_matrix, dtype=np.float64).reshape(3, 3)
            log.info(f"Homography loaded for {self.camera_id}")
        else:
            log.info(f"No homography for {self.camera_id}, using fallback region mapping")
            self._setup_fallback()

        log.info(f"Loaded {len(self._zones)} zone(s) for {self.store_id}")

    def _setup_fallback(self):
        """
        Fallback: divide frame into approximate regions based on camera type.
        Entry camera: left=outside, right=inside threshold.
        Floor camera: grid of zones.
        Billing camera: billing zone = centre/right.
        """
        cam_lower = self.camera_id.lower()

        if "entry" in cam_lower or "exit" in cam_lower:
            # Entry camera — mostly threshold, minimal zone data
            self._fallback_regions = [
                {"zone_id": "ENTRY_THRESHOLD", "x_range": (0.3, 0.7), "y_range": (0.0, 1.0)},
            ]
        elif "billing" in cam_lower or "checkout" in cam_lower:
            self._fallback_regions = [
                {"zone_id": "BILLING", "x_range": (0.0, 1.0), "y_range": (0.0, 1.0)},
            ]
        else:
            # Generic floor zones — divide into quadrants
            self._fallback_regions = [
                {"zone_id": "ZONE_A", "x_range": (0.0, 0.5), "y_range": (0.0, 0.5)},
                {"zone_id": "ZONE_B", "x_range": (0.5, 1.0), "y_range": (0.0, 0.5)},
                {"zone_id": "ZONE_C", "x_range": (0.0, 0.5), "y_range": (0.5, 1.0)},
                {"zone_id": "ZONE_D", "x_range": (0.5, 1.0), "y_range": (0.5, 1.0)},
            ]

    def classify_point(self, cx: float, cy: float, frame_width: int = 1920, frame_height: int = 1080) -> Optional[str]:
        """
        Classify pixel coordinates (cx, cy) into a zone_id.
        Returns None if no zone matches.
        """
        if self._homography is not None and self._zones:
            return self._classify_with_homography(cx, cy)
        else:
            return self._classify_fallback(cx, cy, frame_width, frame_height)

    def _classify_with_homography(self, cx: float, cy: float) -> Optional[str]:
        """Apply homography then check zone polygons."""
        pt = np.array([[[cx, cy]]], dtype=np.float64)
        floor_pt = cv2.perspectiveTransform(pt, self._homography)
        fx, fy = float(floor_pt[0][0][0]), float(floor_pt[0][0][1])

        for zone in self._zones:
            if point_in_polygon(fx, fy, zone["polygon"]):
                return zone["zone_id"]
        return None

    def _classify_fallback(self, cx: float, cy: float, fw: int, fh: int) -> Optional[str]:
        """Relative position fallback."""
        rx = cx / max(fw, 1)
        ry = cy / max(fh, 1)

        # Try layout zones if available (they may have normalised coords)
        for zone in self._zones:
            poly = zone["polygon"]
            if poly and max(p[0] for p in poly) <= 1.0:
                # Normalised polygon
                if point_in_polygon(rx, ry, poly):
                    return zone["zone_id"]

        # Fallback regions
        for region in self._fallback_regions:
            x0, x1 = region["x_range"]
            y0, y1 = region["y_range"]
            if x0 <= rx < x1 and y0 <= ry < y1:
                return region["zone_id"]

        return None

    def get_sku_zone(self, zone_id: str) -> Optional[str]:
        """Return sku_zone label for a zone_id."""
        for zone in self._zones:
            if zone["zone_id"] == zone_id:
                return zone.get("sku_zone")
        return zone_id
