"""
staff_detector.py — Classify whether a detected person is store staff.

Strategy:
  Staff typically wear distinctive uniforms (single-colour tops/vests).
  We use the torso region (middle 40% of bbox height, full width) and analyse
  the dominant colour in HSV space. If the dominant hue cluster matches any
  configured staff uniform colour, we flag as staff.

  Additionally, staff tend to move through ALL zones frequently — we use
  trajectory density as a secondary signal but colour is primary.

  Colour ranges are configurable via STAFF_UNIFORM_HSV_RANGES in store_layout.json.
  Default: generic retail uniform colours (blue, dark navy, black, red).

Fallback:
  If no uniform colour config is found, we flag nobody as staff (conservative —
  better to include staff in metrics than to exclude real customers).
  The is_staff flag is always emitted so downstream can filter.
"""

import logging
import numpy as np
import cv2
from typing import Optional

log = logging.getLogger("staff_detector")

# Default staff uniform HSV ranges (H: 0-180, S: 0-255, V: 0-255)
# Each entry: (hue_low, hue_high, sat_min, val_min, val_max)
DEFAULT_UNIFORM_RANGES = [
    # Dark navy blue
    (100, 130, 80, 30, 120),
    # Royal blue
    (100, 130, 100, 80, 200),
    # Black (low saturation, low value)
    (0, 180, 0, 0, 60),
    # Red/burgundy
    (0, 10, 80, 60, 180),
    (170, 180, 80, 60, 180),
]

# Minimum fraction of torso pixels that must match uniform colour
UNIFORM_MATCH_THRESHOLD = 0.35


class StaffDetector:
    """
    Classifies detected persons as staff or customer using torso colour analysis.
    """

    def __init__(self, uniform_ranges: Optional[list] = None):
        self._ranges = uniform_ranges or DEFAULT_UNIFORM_RANGES
        log.info(f"StaffDetector initialised with {len(self._ranges)} uniform colour range(s)")

    def configure_from_layout(self, store_layout: dict, store_id: str):
        """Override uniform ranges from store_layout.json if provided."""
        for store in store_layout.get("stores", []):
            if store.get("store_id") == store_id:
                custom = store.get("staff_uniform_hsv_ranges")
                if custom:
                    self._ranges = custom
                    log.info(f"Staff uniform ranges loaded from layout for {store_id}")
                    return
        log.debug(f"No custom uniform ranges for {store_id}, using defaults")

    def classify(self, frame: np.ndarray, bbox: list) -> bool:
        """
        Returns True if the person is likely staff.

        Args:
            frame: Full BGR video frame
            bbox:  [x1, y1, x2, y2] bounding box

        Returns:
            is_staff (bool)
        """
        x1, y1, x2, y2 = [int(v) for v in bbox]
        x1 = max(0, x1)
        y1 = max(0, y1)
        x2 = min(frame.shape[1] - 1, x2)
        y2 = min(frame.shape[0] - 1, y2)

        if x2 <= x1 or y2 <= y1:
            return False

        h = y2 - y1
        # Use middle 40% of height as torso region
        torso_y1 = y1 + int(h * 0.30)
        torso_y2 = y1 + int(h * 0.70)

        torso = frame[torso_y1:torso_y2, x1:x2]
        if torso.size == 0:
            return False

        hsv = cv2.cvtColor(torso, cv2.COLOR_BGR2HSV)
        total_pixels = hsv.shape[0] * hsv.shape[1]
        if total_pixels == 0:
            return False

        # Check each configured uniform range
        match_pixels = 0
        for h_low, h_high, s_min, v_min, v_max in self._ranges:
            lower = np.array([h_low, s_min, v_min], dtype=np.uint8)
            upper = np.array([h_high, 255, v_max], dtype=np.uint8)
            mask = cv2.inRange(hsv, lower, upper)
            match_pixels += int(np.sum(mask > 0))

        match_fraction = match_pixels / total_pixels
        is_staff = match_fraction >= UNIFORM_MATCH_THRESHOLD

        if is_staff:
            log.debug(f"Staff detected (uniform match={match_fraction:.2f})")

        return is_staff

    def classify_batch(self, frame: np.ndarray, bboxes: list) -> list[bool]:
        """Classify multiple bounding boxes at once."""
        return [self.classify(frame, bbox) for bbox in bboxes]
