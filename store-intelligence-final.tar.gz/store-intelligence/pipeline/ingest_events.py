"""
ingest_events.py — Post a .jsonl events file to the Intelligence API in batches.

Usage:
    python3 pipeline/ingest_events.py ./data/events.jsonl http://localhost:8000
    python3 pipeline/ingest_events.py ./data/events.jsonl http://localhost:8000 --batch-size 200
    python3 pipeline/ingest_events.py ./data/events.jsonl http://localhost:8000 --simulate-realtime
"""

import json
import sys
import time
import argparse
import logging
import requests
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("ingest")


def ingest_file(events_path: Path, api_url: str, batch_size: int = 100, simulate_realtime: bool = False):
    url = f"{api_url.rstrip('/')}/events/ingest"
    events = []

    with open(events_path) as f:
        for line in f:
            line = line.strip()
            if line:
                try:
                    events.append(json.loads(line))
                except json.JSONDecodeError as e:
                    log.warning(f"Skipping malformed line: {e}")

    log.info(f"Loaded {len(events)} events from {events_path}")

    total_sent = 0
    errors = 0

    for i in range(0, len(events), batch_size):
        batch = events[i:i + batch_size]

        try:
            resp = requests.post(url, json={"events": batch}, timeout=30)
            if resp.status_code in (200, 201, 207):
                result = resp.json()
                ingested = result.get("ingested", len(batch))
                dupes = result.get("duplicates", 0)
                total_sent += ingested
                log.info(f"Batch {i//batch_size + 1}: {ingested} ingested, {dupes} duplicates")
            else:
                log.error(f"Batch {i//batch_size + 1}: HTTP {resp.status_code} — {resp.text[:200]}")
                errors += 1
        except Exception as e:
            log.error(f"Batch {i//batch_size + 1}: Request failed — {e}")
            errors += 1

        if simulate_realtime:
            time.sleep(0.5)  # simulate events arriving over time

    log.info(f"Done. {total_sent} events ingested, {errors} batch errors.")
    return total_sent


def main():
    parser = argparse.ArgumentParser(description="Ingest events.jsonl into Intelligence API")
    parser.add_argument("events_path", type=Path)
    parser.add_argument("api_url", nargs="?", default="http://localhost:8000")
    parser.add_argument("--batch-size", type=int, default=100)
    parser.add_argument("--simulate-realtime", action="store_true", help="Add delay between batches")
    args = parser.parse_args()

    if not args.events_path.exists():
        log.error(f"File not found: {args.events_path}")
        sys.exit(1)

    ingest_file(args.events_path, args.api_url, args.batch_size, args.simulate_realtime)


if __name__ == "__main__":
    main()
