"""
emit.py — Event schema + emission for Store Intelligence Pipeline

Converts raw tracker updates into structured events matching the required schema.
Handles:
  - ENTRY / EXIT event lifecycle
  - ZONE_ENTER / ZONE_EXIT / ZONE_DWELL (every 30s of continuous dwell)
  - BILLING_QUEUE_JOIN (enter billing zone while queue_depth > 0)
  - BILLING_QUEUE_ABANDON (leave billing before a transaction follows)
  - REENTRY detection
  - Buffered writes to .jsonl + optional live POST to API
"""

import uuid
import json
import logging
import requests
from collections import defaultdict
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

log = logging.getLogger("emitter")

# Zone dwell threshold — emit ZONE_DWELL every N seconds of continuous presence
DWELL_INTERVAL_SEC = 30

# Billing abandon threshold — if visitor leaves billing with no POS in this window, = abandon
BILLING_ABANDON_WINDOW_SEC = 300  # 5 minutes

# Queue depth threshold — must have > 0 active billing visitors to emit BILLING_QUEUE_JOIN
QUEUE_DEPTH_THRESHOLD = 1


class VisitorSession:
    """Tracks in-session state for a single visitor_id."""

    def __init__(self, visitor_id: str):
        self.visitor_id = visitor_id
        self.current_zone: Optional[str] = None
        self.zone_enter_time: Optional[datetime] = None
        self.last_dwell_emit: Optional[datetime] = None
        self.session_seq: int = 0
        self.entered: bool = False
        self.exited: bool = False
        self.in_billing: bool = False
        self.billing_enter_time: Optional[datetime] = None
        self.purchased: bool = False   # set by POS correlation

    def next_seq(self) -> int:
        self.session_seq += 1
        return self.session_seq


class EventEmitter:
    """
    Converts tracker update dicts into structured events.

    Output:
      - Appends events as JSONL to output_path
      - Optionally POSTs batches to API in real time
    """

    def __init__(
        self,
        store_id: str,
        camera_id: str,
        output_path: Path,
        api_url: Optional[str] = None,
        batch_size: int = 100,
    ):
        self.store_id = store_id
        self.camera_id = camera_id
        self.output_path = output_path
        self.api_url = api_url
        self.batch_size = batch_size

        self._sessions: dict[str, VisitorSession] = {}
        self._buffer: list[dict] = []
        self._billing_visitors: set[str] = set()  # visitor_ids currently in billing zone

        # Open output file in append mode
        self._outfile = open(output_path, "a", encoding="utf-8")
        log.info(f"EventEmitter ready → {output_path}")

    def process_track_updates(self, updates: list[dict], frame_ts: datetime) -> list[dict]:
        """
        Process a list of tracker update dicts and emit appropriate events.
        Returns list of events emitted this frame.
        """
        emitted = []

        for upd in updates:
            visitor_id = upd["visitor_id"]
            is_staff = upd.get("is_staff", False)
            hints = upd.get("event_hints", [])
            zone_id = upd.get("zone_id")
            confidence = upd.get("confidence", 0.0)

            session = self._get_or_create_session(visitor_id)

            # ── REENTRY ─────────────────────────────────────────────────────
            if "REENTRY" in hints or upd.get("is_reentry"):
                ev = self._make_event(
                    event_type="REENTRY",
                    visitor_id=visitor_id,
                    is_staff=is_staff,
                    confidence=confidence,
                    zone_id=None,
                    dwell_ms=0,
                    session=session,
                    frame_ts=frame_ts,
                )
                emitted.append(ev)
                session.entered = True
                session.exited = False

            # ── ENTRY ────────────────────────────────────────────────────────
            elif "ENTRY" in hints and not session.entered:
                session.entered = True
                ev = self._make_event(
                    event_type="ENTRY",
                    visitor_id=visitor_id,
                    is_staff=is_staff,
                    confidence=confidence,
                    zone_id=None,
                    dwell_ms=0,
                    session=session,
                    frame_ts=frame_ts,
                )
                emitted.append(ev)

            # ── EXIT ─────────────────────────────────────────────────────────
            if "EXIT" in hints and session.entered and not session.exited:
                session.exited = True

                # Check billing abandon
                if session.in_billing and not session.purchased:
                    ev = self._make_event(
                        event_type="BILLING_QUEUE_ABANDON",
                        visitor_id=visitor_id,
                        is_staff=is_staff,
                        confidence=confidence,
                        zone_id="BILLING",
                        dwell_ms=self._dwell_ms(session.billing_enter_time, frame_ts),
                        session=session,
                        frame_ts=frame_ts,
                        extra_meta={"queue_depth": len(self._billing_visitors)},
                    )
                    emitted.append(ev)
                    self._billing_visitors.discard(visitor_id)
                    session.in_billing = False

                ev = self._make_event(
                    event_type="EXIT",
                    visitor_id=visitor_id,
                    is_staff=is_staff,
                    confidence=confidence,
                    zone_id=None,
                    dwell_ms=0,
                    session=session,
                    frame_ts=frame_ts,
                )
                emitted.append(ev)

            # ── ZONE transitions ─────────────────────────────────────────────
            if upd.get("state") == "confirmed" and zone_id != session.current_zone:
                # ZONE_EXIT from previous zone
                if session.current_zone is not None:
                    dwell = self._dwell_ms(session.zone_enter_time, frame_ts)
                    ev = self._make_event(
                        event_type="ZONE_EXIT",
                        visitor_id=visitor_id,
                        is_staff=is_staff,
                        confidence=confidence,
                        zone_id=session.current_zone,
                        dwell_ms=dwell,
                        session=session,
                        frame_ts=frame_ts,
                    )
                    emitted.append(ev)

                    # Billing zone exit — check for abandon
                    if self._is_billing_zone(session.current_zone):
                        self._billing_visitors.discard(visitor_id)
                        session.in_billing = False

                # ZONE_ENTER to new zone
                if zone_id is not None:
                    session.current_zone = zone_id
                    session.zone_enter_time = frame_ts
                    session.last_dwell_emit = frame_ts

                    ev = self._make_event(
                        event_type="ZONE_ENTER",
                        visitor_id=visitor_id,
                        is_staff=is_staff,
                        confidence=confidence,
                        zone_id=zone_id,
                        dwell_ms=0,
                        session=session,
                        frame_ts=frame_ts,
                    )
                    emitted.append(ev)

                    # Billing queue join
                    if self._is_billing_zone(zone_id) and not is_staff:
                        queue_depth = len(self._billing_visitors)
                        self._billing_visitors.add(visitor_id)
                        session.in_billing = True
                        session.billing_enter_time = frame_ts

                        if queue_depth >= QUEUE_DEPTH_THRESHOLD:
                            ev = self._make_event(
                                event_type="BILLING_QUEUE_JOIN",
                                visitor_id=visitor_id,
                                is_staff=is_staff,
                                confidence=confidence,
                                zone_id=zone_id,
                                dwell_ms=0,
                                session=session,
                                frame_ts=frame_ts,
                                extra_meta={"queue_depth": queue_depth},
                            )
                            emitted.append(ev)
                else:
                    session.current_zone = None
                    session.zone_enter_time = None

            # ── ZONE_DWELL (every 30s of continuous presence) ────────────────
            if (
                upd.get("state") == "confirmed"
                and session.current_zone is not None
                and session.last_dwell_emit is not None
            ):
                elapsed = (frame_ts - session.last_dwell_emit).total_seconds()
                if elapsed >= DWELL_INTERVAL_SEC:
                    dwell = self._dwell_ms(session.zone_enter_time, frame_ts)
                    ev = self._make_event(
                        event_type="ZONE_DWELL",
                        visitor_id=visitor_id,
                        is_staff=is_staff,
                        confidence=confidence,
                        zone_id=session.current_zone,
                        dwell_ms=dwell,
                        session=session,
                        frame_ts=frame_ts,
                    )
                    emitted.append(ev)
                    session.last_dwell_emit = frame_ts

        # Write + optionally flush to API
        for ev in emitted:
            self._write(ev)

        return emitted

    def flush(self, frame_ts: datetime):
        """Flush remaining buffer to API and close file."""
        if self._buffer:
            self._post_batch(self._buffer)
            self._buffer.clear()
        self._outfile.flush()
        self._outfile.close()
        log.info("EventEmitter flushed and closed")

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _get_or_create_session(self, visitor_id: str) -> VisitorSession:
        if visitor_id not in self._sessions:
            self._sessions[visitor_id] = VisitorSession(visitor_id)
        return self._sessions[visitor_id]

    def _make_event(
        self,
        event_type: str,
        visitor_id: str,
        is_staff: bool,
        confidence: float,
        zone_id: Optional[str],
        dwell_ms: int,
        session: VisitorSession,
        frame_ts: datetime,
        extra_meta: Optional[dict] = None,
    ) -> dict:
        meta = {
            "queue_depth": extra_meta.get("queue_depth") if extra_meta else None,
            "sku_zone": zone_id,
            "session_seq": session.next_seq(),
        }
        if extra_meta:
            meta.update(extra_meta)

        return {
            "event_id": str(uuid.uuid4()),
            "store_id": self.store_id,
            "camera_id": self.camera_id,
            "visitor_id": visitor_id,
            "event_type": event_type,
            "timestamp": frame_ts.strftime("%Y-%m-%dT%H:%M:%SZ"),
            "zone_id": zone_id,
            "dwell_ms": dwell_ms,
            "is_staff": is_staff,
            "confidence": round(confidence, 4),
            "metadata": meta,
        }

    def _write(self, event: dict):
        """Write event to JSONL file and buffer for API."""
        line = json.dumps(event)
        self._outfile.write(line + "\n")

        if self.api_url:
            self._buffer.append(event)
            if len(self._buffer) >= self.batch_size:
                self._post_batch(self._buffer)
                self._buffer.clear()

    def _post_batch(self, events: list[dict]):
        """POST a batch of events to the Intelligence API."""
        url = f"{self.api_url.rstrip('/')}/events/ingest"
        try:
            resp = requests.post(url, json={"events": events}, timeout=10)
            if resp.status_code not in (200, 201, 207):
                log.warning(f"API ingest returned {resp.status_code}: {resp.text[:200]}")
            else:
                log.debug(f"Posted {len(events)} events to API")
        except Exception as e:
            log.error(f"Failed to POST events to API: {e}")

    @staticmethod
    def _dwell_ms(start: Optional[datetime], end: datetime) -> int:
        if start is None:
            return 0
        return max(0, int((end - start).total_seconds() * 1000))

    @staticmethod
    def _is_billing_zone(zone_id: Optional[str]) -> bool:
        if zone_id is None:
            return False
        z = zone_id.upper()
        return any(k in z for k in ("BILLING", "CHECKOUT", "CASHIER", "POS", "COUNTER"))
