"""
tracker.py — Multi-object tracking + Re-ID for Store Intelligence Pipeline

Tracking strategy:
  - ByteTrack-style IoU matching for within-frame continuity
  - OSNet embeddings for Re-ID across cameras and re-entry detection
  - Entry/exit detection via configurable threshold line on entry camera
  - Cross-camera deduplication: same person on floor + entry camera = 1 visitor
  - Re-entry: same Re-ID embedding after EXIT event within session window

Re-entry policy:
  - If a visitor_id exits and the same embedding re-appears within REENTRY_WINDOW_SEC,
    emit REENTRY event and reuse visitor_id (same visit session)
  - Beyond REENTRY_WINDOW_SEC, assign new visitor_id (new visit)
"""

import uuid
import logging
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime, timezone, timedelta
from typing import Optional

import numpy as np
import cv2

log = logging.getLogger("tracker")

# ── Constants ──────────────────────────────────────────────────────────────────
REENTRY_WINDOW_SEC = 300      # 5 minutes — same person = re-entry
TRACK_MAX_AGE = 30            # frames before a lost track is dropped
MIN_HITS_TO_CONFIRM = 2       # detections before a track is "confirmed"
IOU_THRESHOLD = 0.35          # minimum IoU for track-detection assignment
REID_SIMILARITY_THRESHOLD = 0.65  # cosine similarity for Re-ID match
MAX_EMBEDDING_HISTORY = 10    # embeddings to average per visitor for stability


@dataclass
class Track:
    track_id: int
    visitor_id: str           # VIS_xxxxxx token
    bbox: list                # [x1, y1, x2, y2]
    confidence: float
    is_staff: bool
    zone_id: Optional[str]
    hits: int = 1
    age: int = 0              # frames since last detection
    state: str = "tentative"  # tentative → confirmed → lost
    embedding: Optional[np.ndarray] = None
    embeddings_history: list = field(default_factory=list)
    first_seen: Optional[datetime] = None
    last_seen: Optional[datetime] = None
    session_seq: int = 0      # event ordinal within session
    entered: bool = False
    exited: bool = False
    camera_id: Optional[str] = None

    def update_embedding(self, emb: np.ndarray):
        self.embeddings_history.append(emb)
        if len(self.embeddings_history) > MAX_EMBEDDING_HISTORY:
            self.embeddings_history.pop(0)
        # Average embedding for stability
        self.embedding = np.mean(self.embeddings_history, axis=0)
        norm = np.linalg.norm(self.embedding)
        if norm > 0:
            self.embedding /= norm

    def next_seq(self) -> int:
        self.session_seq += 1
        return self.session_seq


@dataclass
class ExitedVisitor:
    visitor_id: str
    embedding: Optional[np.ndarray]
    exit_time: datetime
    store_id: str


class EmbeddingExtractor:
    """
    Lightweight Re-ID feature extractor.
    Uses OSNet via torchreid if available; falls back to colour histogram
    (HSV histogram of torso region) which is surprisingly effective for retail.
    """

    def __init__(self):
        self._torchreid_available = False
        self._model = None
        self._try_load_torchreid()

    def _try_load_torchreid(self):
        try:
            import torchreid
            import torch
            self._model = torchreid.models.build_model(
                name="osnet_x0_25",
                num_classes=1000,
                pretrained=True,
            )
            self._model.eval()
            if torch.cuda.is_available():
                self._model = self._model.cuda()
            self._torchreid_available = True
            log.info("OSNet Re-ID model loaded (torchreid)")
        except Exception as e:
            log.warning(f"torchreid not available ({e}), using colour histogram Re-ID")

    def extract(self, frame: np.ndarray, bbox: list) -> np.ndarray:
        x1, y1, x2, y2 = [int(v) for v in bbox]
        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(frame.shape[1], x2), min(frame.shape[0], y2)

        if x2 <= x1 or y2 <= y1:
            return np.zeros(128, dtype=np.float32)

        crop = frame[y1:y2, x1:x2]
        if crop.size == 0:
            return np.zeros(128, dtype=np.float32)

        if self._torchreid_available:
            return self._osnet_embedding(crop)
        else:
            return self._histogram_embedding(crop)

    def _histogram_embedding(self, crop: np.ndarray) -> np.ndarray:
        """
        HSV histogram of the torso region (middle third of bbox height).
        Effective for matching same-clothing person across cameras.
        """
        h, w = crop.shape[:2]
        torso = crop[h // 3: 2 * h // 3, :]
        if torso.size == 0:
            torso = crop

        hsv = cv2.cvtColor(torso, cv2.COLOR_BGR2HSV)
        hist_h = cv2.calcHist([hsv], [0], None, [32], [0, 180]).flatten()
        hist_s = cv2.calcHist([hsv], [1], None, [32], [0, 256]).flatten()
        hist_v = cv2.calcHist([hsv], [2], None, [32], [0, 256]).flatten()

        emb = np.concatenate([hist_h, hist_s, hist_v])
        norm = np.linalg.norm(emb)
        if norm > 0:
            emb /= norm
        return emb.astype(np.float32)

    def _osnet_embedding(self, crop: np.ndarray) -> np.ndarray:
        import torch
        import torchvision.transforms as T

        transform = T.Compose([
            T.ToPILImage(),
            T.Resize((256, 128)),
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
        ])
        tensor = transform(crop).unsqueeze(0)
        if next(self._model.parameters()).is_cuda:
            tensor = tensor.cuda()
        with torch.no_grad():
            feat = self._model(tensor)
        emb = feat.cpu().numpy().flatten()
        norm = np.linalg.norm(emb)
        if norm > 0:
            emb /= norm
        return emb.astype(np.float32)


def cosine_similarity(a: np.ndarray, b: np.ndarray) -> float:
    if a is None or b is None:
        return 0.0
    dot = np.dot(a, b)
    return float(np.clip(dot, -1.0, 1.0))


def iou(bbox_a: list, bbox_b: list) -> float:
    ax1, ay1, ax2, ay2 = bbox_a
    bx1, by1, bx2, by2 = bbox_b
    ix1 = max(ax1, bx1)
    iy1 = max(ay1, by1)
    ix2 = min(ax2, bx2)
    iy2 = min(ay2, by2)
    if ix2 <= ix1 or iy2 <= iy1:
        return 0.0
    inter = (ix2 - ix1) * (iy2 - iy1)
    area_a = (ax2 - ax1) * (ay2 - ay1)
    area_b = (bx2 - bx1) * (by2 - by1)
    union = area_a + area_b - inter
    return inter / union if union > 0 else 0.0


def make_visitor_id() -> str:
    return "VIS_" + uuid.uuid4().hex[:6]


class MultiCameraTracker:
    """
    Tracks people across frames (and cameras) for a single store.

    Responsibilities:
      1. Within-frame multi-object tracking (IoU matching, ByteTrack-style)
      2. Re-ID: match new detections to known visitors using embedding similarity
      3. Entry/Exit detection based on camera type + threshold crossing
      4. Re-entry detection: same embedding returning after EXIT
      5. Cross-camera deduplication: suppress duplicate ENTRY if same person
         already has an active session from another camera
    """

    def __init__(self, store_id: str, reid_threshold: float = REID_SIMILARITY_THRESHOLD):
        self.store_id = store_id
        self.reid_threshold = reid_threshold
        self._next_track_id = 1
        self._tracks: dict[int, Track] = {}          # active tracks
        self._exited: list[ExitedVisitor] = []       # recent exits for re-entry check
        self._embedder = EmbeddingExtractor()
        self._visitor_cameras: dict[str, set] = defaultdict(set)  # visitor_id → set of camera_ids

    # ── Public API ─────────────────────────────────────────────────────────────

    def update(
        self,
        detections: list[dict],
        frame: np.ndarray,
        frame_ts: datetime,
        camera_type: str,
    ) -> list[dict]:
        """
        Main update step. Returns list of track_update dicts for event emission.

        Each dict contains:
          track_id, visitor_id, bbox, confidence, is_staff, zone_id,
          event_hints: list of event types to emit (e.g. ['ENTRY', 'ZONE_ENTER'])
          camera_type, first_seen, last_seen, session_seq, embedding
        """
        # Step 1: Extract embeddings for new detections
        for det in detections:
            det["embedding"] = self._embedder.extract(frame, det["bbox"])

        # Step 2: Match detections to existing tracks (IoU first, then Re-ID)
        matched, unmatched_det, unmatched_trk = self._match(detections)

        updates = []

        # Step 3: Update matched tracks
        for det_idx, trk_id in matched:
            det = detections[det_idx]
            trk = self._tracks[trk_id]
            hints = self._update_track(trk, det, frame_ts, camera_type)
            updates.append(self._track_to_update(trk, hints))

        # Step 4: Increment age of unmatched tracks
        for trk_id in unmatched_trk:
            trk = self._tracks[trk_id]
            trk.age += 1
            if trk.age > TRACK_MAX_AGE:
                # Track lost — emit EXIT if it was confirmed and entered
                if trk.state == "confirmed" and trk.entered and not trk.exited:
                    trk.exited = True
                    self._record_exit(trk, frame_ts)
                    updates.append(self._track_to_update(trk, ["EXIT"]))
                del self._tracks[trk_id]

        # Step 5: Initialise new tracks for unmatched detections
        for det_idx in unmatched_det:
            det = detections[det_idx]
            trk = self._init_track(det, frame_ts, camera_type)
            if trk:
                hints = ["ENTRY"] if camera_type == "entry" else []
                updates.append(self._track_to_update(trk, hints))

        # Clean up expired exits
        cutoff = frame_ts - timedelta(seconds=REENTRY_WINDOW_SEC)
        self._exited = [e for e in self._exited if e.exit_time > cutoff]

        return updates

    # ── Internal helpers ───────────────────────────────────────────────────────

    def _match(self, detections: list[dict]) -> tuple:
        """
        Two-stage matching:
          Stage 1 (high confidence): IoU ≥ threshold → definite same person
          Stage 2 (low confidence):  Re-ID similarity for remaining
        Returns: (matched pairs, unmatched_det_indices, unmatched_trk_ids)
        """
        if not self._tracks or not detections:
            return [], list(range(len(detections))), list(self._tracks.keys())

        trk_ids = list(self._tracks.keys())
        matched = []
        used_det = set()
        used_trk = set()

        # Stage 1: IoU matching
        for det_idx, det in enumerate(detections):
            best_iou = IOU_THRESHOLD
            best_trk = None
            for trk_id in trk_ids:
                if trk_id in used_trk:
                    continue
                score = iou(det["bbox"], self._tracks[trk_id].bbox)
                if score > best_iou:
                    best_iou = score
                    best_trk = trk_id
            if best_trk is not None:
                matched.append((det_idx, best_trk))
                used_det.add(det_idx)
                used_trk.add(best_trk)

        # Stage 2: Re-ID for unmatched
        unmatched_det = [i for i in range(len(detections)) if i not in used_det]
        unmatched_trk = [t for t in trk_ids if t not in used_trk]

        for det_idx in list(unmatched_det):
            det = detections[det_idx]
            if det.get("embedding") is None:
                continue
            best_sim = self.reid_threshold
            best_trk = None
            for trk_id in unmatched_trk:
                trk = self._tracks[trk_id]
                if trk.embedding is None:
                    continue
                sim = cosine_similarity(det["embedding"], trk.embedding)
                if sim > best_sim:
                    best_sim = sim
                    best_trk = trk_id
            if best_trk is not None:
                matched.append((det_idx, best_trk))
                unmatched_det.remove(det_idx)
                unmatched_trk.remove(best_trk)

        return matched, unmatched_det, unmatched_trk

    def _update_track(self, trk: Track, det: dict, frame_ts: datetime, camera_type: str) -> list[str]:
        hints = []
        trk.bbox = det["bbox"]
        trk.confidence = det["confidence"]
        trk.is_staff = det.get("is_staff", False)
        trk.age = 0
        trk.hits += 1
        trk.last_seen = frame_ts

        if det.get("embedding") is not None:
            trk.update_embedding(det["embedding"])

        if trk.state == "tentative" and trk.hits >= MIN_HITS_TO_CONFIRM:
            trk.state = "confirmed"
            if camera_type == "entry" and not trk.entered:
                trk.entered = True
                hints.append("ENTRY")

        return hints

    def _init_track(self, det: dict, frame_ts: datetime, camera_type: str) -> Optional[Track]:
        """
        Initialise a new track. Checks Re-ID against exited visitors for re-entry.
        """
        emb = det.get("embedding")

        # Check for re-entry
        reentry_visitor_id = None
        if emb is not None:
            for exited in self._exited:
                if exited.store_id != self.store_id:
                    continue
                sim = cosine_similarity(emb, exited.embedding)
                if sim >= self.reid_threshold:
                    reentry_visitor_id = exited.visitor_id
                    self._exited.remove(exited)
                    log.debug(f"Re-entry detected: {reentry_visitor_id} (similarity={sim:.2f})")
                    break

        # Cross-camera dedup: if this visitor is already active on another camera, skip ENTRY
        is_cross_camera_dup = False
        if emb is not None and reentry_visitor_id is None:
            for trk in self._tracks.values():
                if trk.embedding is not None and trk.state == "confirmed":
                    sim = cosine_similarity(emb, trk.embedding)
                    if sim >= self.reid_threshold and trk.camera_id != det.get("camera_id"):
                        is_cross_camera_dup = True
                        log.debug(f"Cross-camera dup suppressed for {trk.visitor_id}")
                        break

        visitor_id = reentry_visitor_id or make_visitor_id()
        trk = Track(
            track_id=self._next_track_id,
            visitor_id=visitor_id,
            bbox=det["bbox"],
            confidence=det["confidence"],
            is_staff=det.get("is_staff", False),
            zone_id=None,
            first_seen=frame_ts,
            last_seen=frame_ts,
            camera_id=det.get("camera_id"),
        )
        if emb is not None:
            trk.update_embedding(emb)

        self._tracks[self._next_track_id] = trk
        self._next_track_id += 1

        if reentry_visitor_id:
            trk.entered = True
            trk.state = "confirmed"

        return None if is_cross_camera_dup else trk

    def _record_exit(self, trk: Track, frame_ts: datetime):
        if trk.embedding is not None:
            self._exited.append(ExitedVisitor(
                visitor_id=trk.visitor_id,
                embedding=trk.embedding.copy(),
                exit_time=frame_ts,
                store_id=self.store_id,
            ))

    def _track_to_update(self, trk: Track, hints: list[str]) -> dict:
        return {
            "track_id": trk.track_id,
            "visitor_id": trk.visitor_id,
            "bbox": trk.bbox,
            "confidence": trk.confidence,
            "is_staff": trk.is_staff,
            "zone_id": trk.zone_id,
            "event_hints": hints,
            "state": trk.state,
            "first_seen": trk.first_seen,
            "last_seen": trk.last_seen,
            "session_seq": trk.next_seq() if hints else trk.session_seq,
            "is_reentry": "REENTRY" in hints,
        }
