"""
pipeline/validate_events.py — Validate pipeline output against the spec's assertions.

Runs the same checks that assertions.py performs, so you can self-evaluate
your detection pipeline before submission. Also validates against sample_events.jsonl
provided in the challenge dataset.

Usage:
    python3 pipeline/validate_events.py data/events.jsonl
    python3 pipeline/validate_events.py data/events.jsonl --sample data/sample_events.jsonl
    python3 pipeline/validate_events.py data/events.jsonl --strict

Exit code 0 = all assertions pass. Non-zero = failures found.
"""

import json
import sys
import uuid
import argparse
import logging
from pathlib import Path
from datetime import datetime
from collections import defaultdict, Counter

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("validate")

REQUIRED_FIELDS = [
    "event_id", "store_id", "camera_id", "visitor_id",
    "event_type", "timestamp", "dwell_ms", "is_staff",
    "confidence", "metadata",
]

VALID_EVENT_TYPES = {
    "ENTRY", "EXIT", "ZONE_ENTER", "ZONE_EXIT",
    "ZONE_DWELL", "BILLING_QUEUE_JOIN", "BILLING_QUEUE_ABANDON", "REENTRY",
}


def load_jsonl(path: Path) -> list:
    events = []
    errors = 0
    with open(path) as f:
        for i, line in enumerate(f, 1):
            line = line.strip()
            if not line:
                continue
            try:
                events.append(json.loads(line))
            except json.JSONDecodeError as e:
                log.warning(f"Line {i}: JSON parse error — {e}")
                errors += 1
    if errors:
        log.warning(f"{errors} lines failed to parse")
    return events


def validate(events: list, strict: bool = False) -> dict:
    results = {
        "total_events": len(events),
        "passed": [],
        "failed": [],
        "warnings": [],
    }

    def ok(name: str, detail: str = ""):
        results["passed"].append(f"✅ {name}" + (f": {detail}" if detail else ""))

    def fail(name: str, detail: str = ""):
        results["failed"].append(f"❌ {name}" + (f": {detail}" if detail else ""))

    def warn(name: str, detail: str = ""):
        results["warnings"].append(f"⚠️  {name}" + (f": {detail}" if detail else ""))

    if not events:
        fail("Non-empty output", "No events found in file")
        return results

    # ── A1: All required fields present ────────────────────────────────────────
    missing_fields = []
    for i, e in enumerate(events):
        for field in REQUIRED_FIELDS:
            if field not in e:
                missing_fields.append(f"event[{i}] missing '{field}'")
    if missing_fields:
        fail("Required fields", f"{len(missing_fields)} missing — first: {missing_fields[0]}")
    else:
        ok("Required fields", "all events have all required fields")

    # ── A2: event_id is valid UUID and globally unique ─────────────────────────
    event_ids = []
    invalid_uuids = []
    for e in events:
        eid = e.get("event_id", "")
        try:
            uuid.UUID(str(eid))
            event_ids.append(eid)
        except ValueError:
            invalid_uuids.append(eid)
    if invalid_uuids:
        fail("UUID validity", f"{len(invalid_uuids)} invalid UUIDs")
    else:
        ok("UUID validity")

    dupes = len(event_ids) - len(set(event_ids))
    if dupes > 0:
        fail("UUID uniqueness", f"{dupes} duplicate event_ids")
    else:
        ok("UUID uniqueness")

    # ── A3: Timestamps are valid ISO-8601 UTC ─────────────────────────────────
    bad_ts = []
    for i, e in enumerate(events):
        ts = e.get("timestamp", "")
        try:
            datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
        except (ValueError, TypeError):
            bad_ts.append(f"event[{i}]: {ts!r}")
    if bad_ts:
        fail("Timestamp validity", f"{len(bad_ts)} invalid — first: {bad_ts[0]}")
    else:
        ok("Timestamp validity")

    # ── A4: event_type is from the catalogue ──────────────────────────────────
    bad_types = [e.get("event_type") for e in events if e.get("event_type") not in VALID_EVENT_TYPES]
    if bad_types:
        fail("Event type catalogue", f"Invalid types: {set(bad_types)}")
    else:
        ok("Event type catalogue")

    # ── A5: confidence in [0, 1] ──────────────────────────────────────────────
    bad_conf = [i for i, e in enumerate(events) if not (0.0 <= float(e.get("confidence", -1)) <= 1.0)]
    if bad_conf:
        fail("Confidence range", f"{len(bad_conf)} events outside [0,1]")
    else:
        ok("Confidence range")

    # ── A6: dwell_ms non-negative ─────────────────────────────────────────────
    neg_dwell = [i for i, e in enumerate(events) if int(e.get("dwell_ms", 0)) < 0]
    if neg_dwell:
        fail("Dwell non-negative", f"{len(neg_dwell)} negative dwell_ms values")
    else:
        ok("Dwell non-negative")

    # ── A7: is_staff is boolean ───────────────────────────────────────────────
    bad_staff = [i for i, e in enumerate(events) if not isinstance(e.get("is_staff"), bool)]
    if bad_staff:
        fail("is_staff type", f"{len(bad_staff)} events where is_staff is not bool")
    else:
        ok("is_staff type")

    # ── A8: metadata is object with expected keys ─────────────────────────────
    bad_meta = [i for i, e in enumerate(events) if not isinstance(e.get("metadata"), dict)]
    if bad_meta:
        fail("Metadata is object", f"{len(bad_meta)} events with non-object metadata")
    else:
        ok("Metadata is object")

    # ── A9: ENTRY events have null zone_id ────────────────────────────────────
    entry_with_zone = [
        e.get("visitor_id") for e in events
        if e.get("event_type") == "ENTRY" and e.get("zone_id") is not None
    ]
    if entry_with_zone:
        warn("ENTRY zone_id null", f"{len(entry_with_zone)} ENTRY events have non-null zone_id")
    else:
        ok("ENTRY zone_id null")

    # ── A10: ZONE_ENTER/EXIT events have non-null zone_id ─────────────────────
    zone_events_no_zone = [
        i for i, e in enumerate(events)
        if e.get("event_type") in ("ZONE_ENTER", "ZONE_EXIT", "ZONE_DWELL")
        and e.get("zone_id") is None
    ]
    if zone_events_no_zone:
        fail("Zone events have zone_id", f"{len(zone_events_no_zone)} zone events missing zone_id")
    else:
        ok("Zone events have zone_id")

    # ── Stats summary ──────────────────────────────────────────────────────────
    type_counts = Counter(e.get("event_type") for e in events)
    unique_visitors = len(set(
        e.get("visitor_id") for e in events
        if not e.get("is_staff") and e.get("event_type") == "ENTRY"
    ))
    unique_stores = len(set(e.get("store_id") for e in events))
    staff_events = sum(1 for e in events if e.get("is_staff"))
    reentries = type_counts.get("REENTRY", 0)
    low_conf = sum(1 for e in events if float(e.get("confidence", 1)) < 0.4)

    log.info("\n" + "="*50)
    log.info("EVENT STATISTICS")
    log.info("="*50)
    log.info(f"Total events:       {len(events)}")
    log.info(f"Unique stores:      {unique_stores}")
    log.info(f"Unique visitors:    {unique_visitors} (customer ENTRY events)")
    log.info(f"Staff events:       {staff_events}")
    log.info(f"Re-entries:         {reentries}")
    log.info(f"Low-conf (<0.4):    {low_conf}")
    log.info("Event type breakdown:")
    for et, count in sorted(type_counts.items()):
        log.info(f"  {et:<30} {count}")

    return results


def compare_with_sample(events: list, sample_events: list) -> dict:
    """
    Compare your events against sample_events.jsonl from the dataset.
    Checks schema compatibility — not exact match (different visitor_ids expected).
    """
    results = {"passed": [], "failed": []}

    def ok(name): results["passed"].append(f"✅ {name}")
    def fail(name, d=""): results["failed"].append(f"❌ {name}" + (f": {d}" if d else ""))

    # Check your events have all event types present in sample
    sample_types = set(e.get("event_type") for e in sample_events)
    your_types = set(e.get("event_type") for e in events)
    missing = sample_types - your_types
    if missing:
        fail("Event type coverage", f"Sample has these types you don't: {missing}")
    else:
        ok("Event type coverage matches sample")

    # Check schema fields match
    if sample_events and events:
        sample_fields = set(sample_events[0].keys())
        your_fields = set(events[0].keys())
        missing_fields = sample_fields - your_fields
        extra_fields = your_fields - sample_fields
        if missing_fields:
            fail("Schema fields", f"Missing from your events: {missing_fields}")
        else:
            ok("Schema fields match sample")
        if extra_fields:
            results["passed"].append(f"ℹ️  Extra fields (ok): {extra_fields}")

    # Check metadata structure
    sample_meta_keys = set()
    for e in sample_events:
        if isinstance(e.get("metadata"), dict):
            sample_meta_keys.update(e["metadata"].keys())

    your_meta_keys = set()
    for e in events:
        if isinstance(e.get("metadata"), dict):
            your_meta_keys.update(e["metadata"].keys())

    missing_meta = sample_meta_keys - your_meta_keys
    if missing_meta:
        fail("Metadata keys", f"Missing: {missing_meta}")
    else:
        ok("Metadata keys match sample")

    return results


def main():
    parser = argparse.ArgumentParser(description="Validate pipeline events against spec")
    parser.add_argument("events_path", type=Path, help="Path to events.jsonl")
    parser.add_argument("--sample", type=Path, default=None, help="Path to sample_events.jsonl")
    parser.add_argument("--strict", action="store_true", help="Exit non-zero on warnings too")
    args = parser.parse_args()

    if not args.events_path.exists():
        log.error(f"File not found: {args.events_path}")
        sys.exit(1)

    log.info(f"Loading events from {args.events_path}...")
    events = load_jsonl(args.events_path)
    log.info(f"Loaded {len(events)} events")

    results = validate(events, strict=args.strict)

    print("\n" + "="*55)
    print("VALIDATION RESULTS")
    print("="*55)
    for msg in results["passed"]:
        print(msg)
    for msg in results["warnings"]:
        print(msg)
    for msg in results["failed"]:
        print(msg)

    if args.sample and args.sample.exists():
        print("\n" + "="*55)
        print("SAMPLE COMPARISON")
        print("="*55)
        sample_events = load_jsonl(args.sample)
        cmp = compare_with_sample(events, sample_events)
        for msg in cmp["passed"] + cmp["failed"]:
            print(msg)
        if cmp["failed"]:
            results["failed"].extend(cmp["failed"])

    print("="*55)
    total_pass = len(results["passed"])
    total_fail = len(results["failed"])
    total_warn = len(results["warnings"])
    print(f"PASSED: {total_pass}  |  FAILED: {total_fail}  |  WARNINGS: {total_warn}")
    print("="*55)

    if total_fail > 0:
        sys.exit(1)
    if args.strict and total_warn > 0:
        sys.exit(2)
    sys.exit(0)


if __name__ == "__main__":
    main()
