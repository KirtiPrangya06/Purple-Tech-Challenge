#!/usr/bin/env bash
# run.sh — One command to process all CCTV clips and emit events
#
# Usage:
#   ./pipeline/run.sh [CLIPS_DIR] [LAYOUT_JSON] [OUTPUT_JSONL] [API_URL]
#
# Defaults:
#   CLIPS_DIR   = ./data/clips
#   LAYOUT_JSON = ./data/store_layout.json
#   OUTPUT_JSONL= ./data/events.jsonl
#   API_URL     = http://localhost:8000  (set to empty string to disable live ingest)
#
# Examples:
#   ./pipeline/run.sh
#   ./pipeline/run.sh ./data/clips ./data/store_layout.json ./data/events.jsonl
#   ./pipeline/run.sh ./data/clips ./data/store_layout.json ./data/events.jsonl http://localhost:8000

set -euo pipefail

CLIPS_DIR="${1:-./data/clips}"
LAYOUT_JSON="${2:-./data/store_layout.json}"
OUTPUT_JSONL="${3:-./data/events.jsonl}"
API_URL="${4:-http://localhost:8000}"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

echo "============================================"
echo "  Store Intelligence — Detection Pipeline"
echo "============================================"
echo "  Clips dir   : $CLIPS_DIR"
echo "  Layout      : $LAYOUT_JSON"
echo "  Output      : $OUTPUT_JSONL"
echo "  API URL     : ${API_URL:-'(disabled — batch mode)'}"
echo "============================================"

# Verify clips directory exists
if [ ! -d "$CLIPS_DIR" ]; then
    echo "ERROR: Clips directory not found: $CLIPS_DIR"
    echo "  Please extract the challenge dataset to $CLIPS_DIR"
    exit 1
fi

# Verify layout file exists
if [ ! -f "$LAYOUT_JSON" ]; then
    echo "ERROR: store_layout.json not found: $LAYOUT_JSON"
    exit 1
fi

# Create output directory
mkdir -p "$(dirname "$OUTPUT_JSONL")"

# Check Python environment
if ! command -v python3 &>/dev/null; then
    echo "ERROR: python3 not found. Please install Python 3.10+"
    exit 1
fi

# Install pipeline dependencies if needed
echo ""
echo "Checking pipeline dependencies..."
pip install -q ultralytics opencv-python-headless requests numpy torchreid 2>/dev/null || \
pip install -q ultralytics opencv-python-headless requests numpy 2>/dev/null || true

echo ""
echo "Starting detection pipeline..."
echo ""

cd "$PROJECT_ROOT"

if [ -n "$API_URL" ]; then
    python3 pipeline/detect.py \
        "$CLIPS_DIR" \
        "$LAYOUT_JSON" \
        "$OUTPUT_JSONL" \
        --api-url "$API_URL" \
        --batch-size 100
else
    python3 pipeline/detect.py \
        "$CLIPS_DIR" \
        "$LAYOUT_JSON" \
        "$OUTPUT_JSONL"
fi

echo ""
echo "============================================"
echo "  Pipeline complete!"
echo "  Events written to: $OUTPUT_JSONL"
LINECOUNT=$(wc -l < "$OUTPUT_JSONL" 2>/dev/null || echo "0")
echo "  Total events: $LINECOUNT"
echo "============================================"

# Load POS transactions if available
POS_CSV="${PROJECT_ROOT}/data/pos_transactions.csv"
if [ -f "$POS_CSV" ]; then
    echo ""
    echo "Loading POS transactions..."
    python3 pipeline/load_pos.py "$POS_CSV" --api "${API_URL:-http://localhost:8000}" 2>/dev/null || \
    python3 pipeline/load_pos.py "$POS_CSV" --db "./data/store_intelligence.db"
fi

# Validate output schema
SAMPLE_EVENTS="${PROJECT_ROOT}/data/sample_events.jsonl"
echo ""
echo "Validating event schema..."
if [ -f "$SAMPLE_EVENTS" ]; then
    python3 pipeline/validate_events.py "$OUTPUT_JSONL" --sample "$SAMPLE_EVENTS"
else
    python3 pipeline/validate_events.py "$OUTPUT_JSONL"
fi

echo ""
echo "To ingest events into the API manually:"
echo "  python3 pipeline/ingest_events.py $OUTPUT_JSONL ${API_URL:-http://localhost:8000}"
echo ""
echo "To validate events:"
echo "  python3 pipeline/validate_events.py $OUTPUT_JSONL"
echo ""
