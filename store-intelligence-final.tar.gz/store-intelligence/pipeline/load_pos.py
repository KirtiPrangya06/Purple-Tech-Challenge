"""
pipeline/load_pos.py — Load pos_transactions.csv into the Intelligence API database.

The POS data is used for conversion rate calculation:
  A visitor in the billing zone within 5 minutes before a transaction = converted.

Usage:
    python3 pipeline/load_pos.py data/pos_transactions.csv
    python3 pipeline/load_pos.py data/pos_transactions.csv --api http://localhost:8000
    python3 pipeline/load_pos.py data/pos_transactions.csv --db data/store_intelligence.db

CSV format:
    store_id, transaction_id, timestamp, basket_value_inr
    STORE_BLR_002, TXN_00441, 2026-03-03T14:38:12Z, 1240.00
"""

import csv
import sys
import argparse
import logging
import asyncio
import os
from pathlib import Path

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("load_pos")


async def load_to_db(csv_path: Path, db_path: str):
    """Load POS transactions directly into SQLite."""
    os.environ["DATABASE_URL"] = db_path
    import app.db.database as db_mod
    db_mod.DB_PATH = db_path

    from app.db.database import init_db
    from app.services.ingestion import ingest_pos_transactions

    await init_db(db_path)

    transactions = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            # Normalise column names (strip whitespace)
            row = {k.strip(): v.strip() for k, v in row.items()}
            transactions.append({
                "store_id": row.get("store_id", ""),
                "transaction_id": row.get("transaction_id", ""),
                "timestamp": row.get("timestamp", ""),
                "basket_value_inr": float(row.get("basket_value_inr", 0)),
            })

    log.info(f"Loaded {len(transactions)} rows from {csv_path}")
    count, _ = await ingest_pos_transactions(transactions)
    log.info(f"Inserted {count} POS transactions into {db_path}")
    return count


def load_via_api(csv_path: Path, api_url: str):
    """POST POS transactions to the API (if a /pos/ingest endpoint exists)."""
    import requests, csv

    transactions = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row = {k.strip(): v.strip() for k, v in row.items()}
            transactions.append({
                "store_id": row.get("store_id", ""),
                "transaction_id": row.get("transaction_id", ""),
                "timestamp": row.get("timestamp", ""),
                "basket_value_inr": float(row.get("basket_value_inr", 0)),
            })

    url = f"{api_url.rstrip('/')}/pos/ingest"
    batch_size = 200
    total = 0
    for i in range(0, len(transactions), batch_size):
        batch = transactions[i:i + batch_size]
        try:
            resp = requests.post(url, json={"transactions": batch}, timeout=30)
            if resp.status_code in (200, 201):
                total += resp.json().get("ingested", len(batch))
            else:
                log.warning(f"Batch {i//batch_size+1}: HTTP {resp.status_code}")
        except Exception as e:
            log.error(f"Batch {i//batch_size+1}: {e}")
    log.info(f"Sent {total} POS transactions via API")


def main():
    parser = argparse.ArgumentParser(description="Load POS CSV into Store Intelligence")
    parser.add_argument("csv_path", type=Path, help="Path to pos_transactions.csv")
    parser.add_argument("--db", default="./data/store_intelligence.db", help="SQLite DB path")
    parser.add_argument("--api", default=None, help="API URL (uses direct DB if not set)")
    args = parser.parse_args()

    if not args.csv_path.exists():
        log.error(f"File not found: {args.csv_path}")
        sys.exit(1)

    if args.api:
        load_via_api(args.csv_path, args.api)
    else:
        asyncio.run(load_to_db(args.csv_path, args.db))


if __name__ == "__main__":
    main()
