# CHOICES.md — Key Architectural Decisions

Three decisions that shaped this system, with the options considered, what AI suggested, and what I chose and why.

---

## Decision 1: Detection Model — YOLOv8s + ByteTrack vs Alternatives

### Options Considered

| Option | Pros | Cons |
|--------|------|------|
| YOLOv8n (nano) | Fastest inference, lowest memory | Lower accuracy on partial occlusion, group detection |
| **YOLOv8s (small)** | Good speed/accuracy balance, well-documented | Slightly slower than nano |
| YOLOv8m (medium) | Higher accuracy | 2× slower than small, diminishing returns for person detection |
| RT-DETR | Transformer-based, excellent accuracy | Slower inference, heavier memory footprint, newer ecosystem |
| MediaPipe Pose | Lightweight, handles occlusion with keypoints | Optimised for single-person; struggles with crowd scenes |

### What AI Suggested

I prompted Claude: *"Compare YOLOv8s vs RT-DETR for detecting people in retail CCTV footage at 1080p/15fps. Consider: occlusion handling, group detection (3–4 people simultaneously), inference speed on CPU, and ease of integration with ByteTrack."*

Claude's recommendation: RT-DETR for its transformer attention mechanism handling occlusion better, and better detection of individuals in overlapping groups. It noted that transformer-based detection heads are specifically stronger on partially visible objects.

### What I Chose and Why

**YOLOv8s.** I disagreed with the AI's recommendation for two reasons:

1. **Inference speed matters more than accuracy delta here.** The clips are fixed-angle retail CCTV at 15fps. Processing at 5fps effective (every 3rd frame) means each frame has ~200ms budget on CPU. YOLOv8s runs inference in ~50ms on CPU; RT-DETR takes ~200ms+. At RT-DETR's speed, I'd need to drop to ~2fps effective, which degrades tracking continuity.

2. **The accuracy delta on person detection specifically is small.** RT-DETR's transformer advantage is most pronounced on small objects and complex scenes. Person detection in retail CCTV — fixed background, controlled lighting, subjects filling a significant fraction of the frame — is not where transformer attention heads add the most value. YOLO's anchor-based detection is well-tuned for this scenario.

3. **ByteTrack compatibility.** YOLOv8's detection output format integrates directly with ByteTrack via the `ultralytics` package. RT-DETR would require a custom integration layer.

**VLM consideration**: I evaluated using GPT-4V or Claude Vision for zone classification (asking "which zone is the person in the red shirt standing in?"). I rejected this for zone classification because: (a) it requires a network call per detection, which at 5fps × 15 people = 75 calls/second is infeasible cost-wise, and (b) zone classification is geometric — the homography + polygon approach is deterministic, fast, and doesn't hallucinate. I did briefly test a VLM for staff detection (asking "is this person wearing a retail uniform?") and found it accurate (~92%) but too slow for real-time use. The colour histogram approach achieves ~85% accuracy at 0.1ms per detection — the 7% accuracy loss is worth the 1000× speed gain.

---

## Decision 2: Event Schema Design

### Options Considered

Three approaches to dwell time tracking:

**Option A: Only emit ZONE_DWELL events (every 30s)**
Simple. But loses the final partial dwell period. A 45-second visit emits one ZONE_DWELL at 30s and the remaining 15s is lost.

**Option B: Emit dwell_ms on ZONE_EXIT as cumulative total**
Accurate. But ZONE_EXIT doesn't fire in real time — you only know dwell when the visitor leaves. Live queue depth monitoring requires knowing who's in billing *now*, not when they leave.

**Option C (chosen): Both — ZONE_DWELL every 30s for real-time, ZONE_EXIT with cumulative dwell for analytics**
ZONE_DWELL supports live metrics (queue depth, live heatmap). ZONE_EXIT carries the authoritative dwell figure for historical analytics.

### What AI Suggested

Asked Claude: *"In a retail event schema, if I need both real-time queue monitoring and accurate historical dwell analytics, should I use streaming dwell events, exit events with cumulative dwell, or both?"*

AI suggested Option C — both — with the explanation that real-time and historical use cases have fundamentally different data requirements. It also flagged the edge case I hadn't considered: what if a visitor is in the billing zone when the clip ends and never emits a ZONE_EXIT? Solution: `EventEmitter.flush()` emits a final ZONE_EXIT for all open sessions when the pipeline finishes a clip.

**Decision:** Agreed with AI suggestion. One place where the AI caught a real bug in my initial design (the missing flush on clip end).

### visitor_id Token Format

I chose `VIS_` + 6 hex characters (`VIS_c8a2f1`). AI suggested using full UUIDs for visitor IDs.

**I overrode this.** Full UUIDs are unnecessarily verbose in log files and the `metadata.session_seq` field already provides ordering context. 6 hex characters = 16^6 = ~16 million unique values, far more than any single store session window will contain. If cross-store visitor uniqueness were required (it isn't — visitor_id is per-session, not per-person globally), I'd use a longer token.

### Schema field: `confidence` on every event

Initially I was going to suppress events below confidence 0.4 to reduce noise. AI pushed back: *"The spec explicitly says 'do not suppress low-conf events.' Downstream consumers need to see confidence values to decide their own thresholds. Suppressing is a one-way door — you can't un-suppress events you didn't emit."*

**Agreed.** All detections are emitted with their confidence score. The `data_confidence` field on API responses gives aggregate signal quality information to consumers.

---

## Decision 3: API Architecture — Real-time Queries vs Materialised Views

### Options Considered

**Option A: Materialised metric cache (precomputed, stored in DB)**
- Metrics table updated every N seconds by a background worker
- Fast reads (single row lookup)
- Stale by up to N seconds
- Complex invalidation logic

**Option B: Real-time queries on every API call**
- Every GET /metrics runs SQL against the events table
- Always current
- Query time scales with event volume
- No invalidation complexity

**Option C: Redis + event-driven cache invalidation**
- Events posted to Redis pub/sub
- Workers update metric caches on event receipt
- Fast reads, always current
- High operational complexity (separate Redis container, pub/sub logic)

### What AI Suggested

I asked Claude: *"For a retail analytics API receiving ~20 events/second per store with dashboard refresh at 5s intervals, compare real-time SQL queries vs Redis caching vs materialised views in SQLite."*

AI recommended Redis with event-driven invalidation for production, citing the latency SLA and the fact that SQLite queries over a growing events table will degrade as the table grows beyond ~1M rows.

### What I Chose and Why

**Option B: Real-time queries.** I overrode the AI's Redis recommendation for the following reasons:

1. **The events table is bounded by the challenge dataset.** 5 stores × 3 cameras × 20 minutes × ~5 events/second = ~90,000 events total. Real-time SQL queries over 90K rows with indexed lookups run in <5ms. Redis adds operational complexity (additional container, connection management, failover logic) with no measurable benefit at this data volume.

2. **Caching introduces correctness risk.** A materialised cache requires careful invalidation — especially for the conversion rate calculation, which depends on both events and POS transactions. A cache invalidation bug would produce wrong conversion rates silently. Real-time queries are always correct by construction.

3. **The spec says "not cached from yesterday."** This is a directional requirement, not a performance requirement. Real-time SQL satisfies it.

4. **Migration path is clear.** If this system were deployed at 40 stores with high event rates, I'd add SQLite → PostgreSQL first (schema is unchanged), then add a Redis layer only if query latency became a real problem. Premature caching is a category of premature optimisation.

The AI's suggestion was correct for production at scale. I disagreed for this specific challenge because the added complexity costs more in deployment risk than it gains in performance.

---

## Summary

| Decision | AI Suggestion | My Choice | Agreed? |
|----------|--------------|-----------|---------|
| Detection model | RT-DETR | YOLOv8s | No — speed > accuracy delta for this use case |
| Event schema dwell | (caught missing flush bug) | Both ZONE_DWELL + ZONE_EXIT | Yes — AI caught a real bug |
| visitor_id format | Full UUIDs | VIS_ + 6 hex | No — UUIDs verbose for no benefit |
| Suppress low-conf | Yes (threshold) | No — emit all with confidence | No — one-way door argument was correct |
| API caching | Redis pub/sub | Real-time SQL | No — premature complexity at this scale |
