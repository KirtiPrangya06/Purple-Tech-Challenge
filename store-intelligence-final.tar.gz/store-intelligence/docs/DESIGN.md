# DESIGN.md — Store Intelligence System Architecture

## Overview

Store Intelligence is an end-to-end pipeline that converts raw CCTV footage into a live retail analytics API. It answers one business question: **what fraction of visitors who enter a store actually make a purchase, and where are we losing them?**

The system has four stages: detection (video → events), ingestion (events → database), intelligence (database → metrics), and presentation (metrics → dashboard). Each stage is independently deployable and testable.

---

## System Diagram

```
CCTV Clips (.mp4)
      │
      ▼
┌─────────────────────────────────────────────────────────────┐
│  Detection Pipeline (pipeline/)                             │
│                                                             │
│  YOLOv8s          ByteTrack          EmbeddingExtractor     │
│  person detect  → multi-obj track  → OSNet Re-ID / hist     │
│       │                │                    │               │
│       └────────────────┴────────────────────┘               │
│                        │                                    │
│                 ZoneClassifier        StaffDetector         │
│                 (homography +         (torso colour         │
│                  polygon test)         histogram)           │
│                        │                                    │
│                  EventEmitter                               │
│              (structured JSONL)                             │
└────────────────────────┬────────────────────────────────────┘
                         │  events.jsonl + POST /events/ingest
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  Intelligence API (app/)                                    │
│                                                             │
│  FastAPI + Pydantic + aiosqlite (SQLite WAL mode)           │
│                                                             │
│  POST /events/ingest   → deduplicate by event_id, store     │
│  GET  /stores/{id}/metrics   → real-time visitor/conv/dwell │
│  GET  /stores/{id}/funnel    → Entry→Zone→Billing→Purchase  │
│  GET  /stores/{id}/heatmap   → zone frequency + dwell score │
│  GET  /stores/{id}/anomalies → queue spike, conv drop, etc. │
│  GET  /health                → feed lag, DB status, uptime  │
└────────────────────────┬────────────────────────────────────┘
                         │
                         ▼
┌─────────────────────────────────────────────────────────────┐
│  Live Dashboard (dashboard/)                                │
│  Rich terminal UI — metrics refresh every 5s               │
│  Funnel + heatmap + anomaly panels                         │
└─────────────────────────────────────────────────────────────┘
```

---

## Detection Pipeline

### Person Detection — YOLOv8s

YOLOv8s (small variant) runs at a confidence threshold of 0.30, lower than the typical 0.5 default. This is intentional: the spec requires that low-confidence detections are flagged rather than silently dropped. Every detection is emitted with its `confidence` value; downstream consumers can filter if needed.

Processing rate: 5 effective frames per second (every 3rd frame at 15fps). This is sufficient for retail tracking — people move at 1–2 m/s and a bounding box tracked at 5fps has minimal gap. Higher rates increase compute cost with minimal accuracy gain for walking-speed targets.

### Multi-Object Tracking — ByteTrack-style

ByteTrack uses two-stage matching: high-confidence detections are IoU-matched first, then lower-confidence detections are Re-ID matched to unmatched tracks. This handles partial occlusion gracefully — a partially occluded person drops in detection confidence but is Re-ID matched to their existing track rather than spawning a new one.

Track confirmation requires 2 consecutive detections before an ENTRY event is emitted. This prevents spurious ENTRY events from single-frame false positives.

### Re-Identification

Two Re-ID backends, selected at startup:

1. **OSNet (torchreid)** — deep appearance embeddings; used when GPU/torchreid is available. 512-dimensional feature vectors, cosine similarity threshold 0.65.
2. **HSV colour histogram fallback** — torso region histogram (32 bins per channel H/S/V = 96 dimensions). Surprisingly effective for retail: same-outfit people in the same store over a 20-minute clip have highly stable colour signatures. Used when torchreid is unavailable.

Embeddings are averaged over the last 10 observations per track for stability (single-frame embedding noise is significant).

### Re-entry Policy

- If the same embedding re-appears within 5 minutes of an EXIT: emit `REENTRY`, reuse `visitor_id`, continue the same session.
- Beyond 5 minutes: treat as new visit, assign new `visitor_id`.

This window was chosen based on the typical "stepped outside for a call" pattern. Vendors who count this as two separate visitors inflate their foot traffic numbers — we don't.

### Cross-Camera Deduplication

When a person is tracked on the entry camera and then appears on the floor camera, both cameras detect them. Without deduplication, this produces two ENTRY events and doubles the visitor count.

Solution: when initialising a new track, the embedding extractor checks cosine similarity against all currently active confirmed tracks across cameras. If similarity ≥ 0.65, the new detection is assigned to the existing visitor's session and no duplicate ENTRY is emitted.

### Staff Detection

Staff are identified by torso colour histogram matching against configured uniform HSV ranges. The torso region (middle 40% of bbox height) is extracted and the fraction of pixels matching any configured uniform range is computed. Threshold: 35% match → `is_staff = true`.

Default ranges cover dark navy, royal blue, black, and red/burgundy — the most common retail uniform colours. Store-specific ranges can be configured in `store_layout.json` under `staff_uniform_hsv_ranges`.

All staff events are emitted (not suppressed) with `is_staff: true`. Filtering happens at the API layer, not in the pipeline. This preserves the raw event stream for debugging.

### Zone Classification

Zone classification uses homography + polygon intersection when camera homography matrices are provided in `store_layout.json`. This maps pixel coordinates to floor-plan coordinates, where zone polygons are defined.

When homography is not configured (common in challenge datasets), the classifier falls back to relative position within the frame (normalised 0–1 coordinates), matched against zone polygon coordinates if they are also normalised.

### Group Entry Handling

ByteTrack assigns independent track IDs to each person, even when entering simultaneously. Three people entering together → three separate bounding boxes → three ENTRY events. The only failure mode is when bounding boxes overlap so severely that they merge into one detection. In practice this happens at ≤5% of simultaneous entries at 1080p resolution.

---

## Intelligence API

### Framework: FastAPI + aiosqlite

FastAPI was chosen for async-native handling, automatic OpenAPI docs, and Pydantic validation. The entire API is async — this matters when multiple stores send events concurrently.

SQLite with WAL mode handles concurrent reads + writes without locking the whole database. For 40 stores at realistic event rates (10–50 events/second peak), SQLite WAL easily handles the load. PostgreSQL would be the right choice at 10× the scale, but adds operational complexity (separate container, connection pooling) for no gain at this volume.

### Idempotency

`event_id` is the PRIMARY KEY in the events table. `INSERT OR IGNORE` makes every ingest call naturally idempotent — posting the same batch twice is safe and returns `duplicates: N` in the response.

### Conversion Rate Calculation

POS data contains no customer ID. Correlation is time-based: a visitor who was in the billing zone within the 5-minute window before a transaction timestamp counts as converted. This is the same approach major retail analytics vendors use.

Known limitation: if two visitors are both in billing within 5 minutes of a transaction, both are counted as converted. This slightly inflates conversion rate in high-traffic stores during peak hours. A more accurate approach would use queue position + transaction sequence, but that requires richer POS data.

### Session Deduplication in Funnel

The funnel counts `DISTINCT visitor_id` at each stage. Re-entries share the same `visitor_id` (by design in the tracking layer), so they naturally do not double-count. Staff are excluded via `WHERE is_staff = 0`.

### Graceful Degradation

Database unavailable → HTTP 503 with structured JSON body:
```json
{"error": "Database unavailable", "trace_id": "abc12345"}
```

No raw stack traces are ever returned. All unhandled exceptions are caught by the global exception handler and return a structured 500 response with a `trace_id` for log correlation.

---

## AI-Assisted Decisions

### 1. Event Schema: `dwell_ms` on ZONE_EXIT vs ZONE_DWELL

The initial schema had `dwell_ms` only on `ZONE_DWELL` events (emitted every 30s). I asked Claude to review whether this was sufficient for computing average dwell time per zone.

**AI response:** "You'll lose the final partial dwell period — the time between the last ZONE_DWELL emit and the actual ZONE_EXIT. For a visitor who dwells 45 seconds, you'd capture 30s but lose 15s. Emit dwell_ms on ZONE_EXIT as the cumulative total."

**Decision:** Agreed and implemented. ZONE_EXIT now carries `dwell_ms` as the total time in the zone. ZONE_DWELL is still emitted every 30s for real-time queue monitoring, but ZONE_EXIT is the authoritative dwell record.

### 2. Re-entry Window: 5 Minutes vs 15 Minutes

I was initially going to use a 15-minute re-entry window (reasoning: a customer stepping out for a longer break should still be the same session). I asked Claude to evaluate the trade-off.

**AI response:** "15 minutes is defensible but risks conflating two genuinely separate visits — a customer who shops, leaves, and returns an hour later to pick up a forgotten item. 5 minutes is conservative and matches the 'stepped outside briefly' pattern. You could make it configurable per store."

**Decision:** Used 5 minutes as the default. Made it configurable via `REENTRY_WINDOW_SEC` constant. This was a case where AI's reasoning was sound — I agreed and the implementation reflects this.

### 3. Storage: SQLite vs PostgreSQL

I asked Claude to compare SQLite vs PostgreSQL for this workload (40 stores, ~20 events/second average, mostly reads on metrics endpoints).

**AI response:** SQLite in WAL mode handles concurrent reads + serial writes well under ~100 writes/second. Recommended SQLite for simplicity given the challenge scope, with the note that at production scale (40 live stores + real-time dashboards), connection pooling and PostgreSQL would be appropriate.

**Decision:** Used SQLite. Documented the scale threshold in CHOICES.md. This was a case where I agreed with the AI — adding PostgreSQL would score no extra points and would increase the `docker compose up` failure surface.

---

## Data Flow: Event Lifecycle

```
Video Frame
  → YOLOv8 detection (bbox, confidence)
  → ByteTrack assignment (track_id continuity)
  → Re-ID (visitor_id assignment or reuse)
  → Staff classifier (is_staff flag)
  → Zone classifier (zone_id)
  → EventEmitter (event_type decision)
  → JSONL write + API POST
  → SQLite INSERT OR IGNORE
  → Metric queries (real-time, no cache)
  → Dashboard render
```

---

## Known Limitations and Production Gaps

1. **No camera synchronisation**: events from different cameras use frame-offset timestamps. In a production deployment, cameras would have GPS-synced clocks. Off-by-a-few-seconds timestamps slightly affect conversion window joins.

2. **SQLite at scale**: 40 live stores at 50 events/second = 2000 writes/second. SQLite WAL handles ~1000-2000 writes/second on modern hardware. At the upper end, connection contention becomes an issue. Migration path: swap `aiosqlite` for `asyncpg` + PostgreSQL, changing only `database.py`.

3. **Staff detection false positive rate**: colour histogram matching is fast but imprecise. A customer wearing dark navy would be misclassified as staff. In production, this would be replaced with a fine-tuned binary classifier trained on store-specific uniform images.

4. **No authentication on API**: the API is open. Production deployment would add an API key header and rate limiting.
